import { chromium } from "playwright";
import { writeFileSync } from "node:fs";

function mulberry32(seed) {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function stars(w, h, n, seed) {
  const rand = mulberry32(seed);
  const out = [];
  for (let i = 0; i < n; i += 1) {
    const x = (rand() * w).toFixed(1);
    const y = (rand() * h).toFixed(1);
    const big = rand() < 0.07;
    const r = (big ? 1.6 + rand() * 1.5 : 0.35 + rand() * 1.05).toFixed(2);
    const o = (0.22 + rand() * 0.72).toFixed(2);
    const roll = rand();
    const c = roll < 0.1 ? "#f0b429" : roll < 0.2 ? "#2ec4b6" : "#f4f7f6";
    out.push(
      `<circle cx="${x}" cy="${y}" r="${r}" fill="${c}" opacity="${o}"/>`,
    );
  }
  return out.join("");
}

const DEFS = `
  <linearGradient id="gold" x1="0" y1="0" x2="0" y2="1">
    <stop offset="0%" stop-color="#fff1c2"/>
    <stop offset="42%" stop-color="#f0b429"/>
    <stop offset="100%" stop-color="#b7791f"/>
  </linearGradient>
  <linearGradient id="goldSoft" x1="0" y1="0" x2="1" y2="1">
    <stop offset="0%" stop-color="#ffe7a3"/>
    <stop offset="100%" stop-color="#c4841a"/>
  </linearGradient>
  <linearGradient id="panel" x1="0" y1="0" x2="0" y2="1">
    <stop offset="0%" stop-color="#9ff7ee"/>
    <stop offset="100%" stop-color="#148f84"/>
  </linearGradient>
  <linearGradient id="visor" x1="0" y1="0" x2="0" y2="1">
    <stop offset="0%" stop-color="#1c6f74"/>
    <stop offset="55%" stop-color="#0c3338"/>
    <stop offset="100%" stop-color="#07141c"/>
  </linearGradient>
  <radialGradient id="sky" cx="50%" cy="42%" r="62%">
    <stop offset="0%" stop-color="#14524e"/>
    <stop offset="38%" stop-color="#0c2c34"/>
    <stop offset="100%" stop-color="#07141c"/>
  </radialGradient>
  <radialGradient id="amber" cx="70%" cy="38%" r="36%">
    <stop offset="0%" stop-color="#f0b429" stop-opacity="0.28"/>
    <stop offset="100%" stop-color="#f0b429" stop-opacity="0"/>
  </radialGradient>
  <radialGradient id="vignette" cx="50%" cy="46%" r="72%">
    <stop offset="52%" stop-color="#000" stop-opacity="0"/>
    <stop offset="100%" stop-color="#02080c" stop-opacity="0.72"/>
  </radialGradient>
  <filter id="glow" x="-40%" y="-40%" width="180%" height="180%">
    <feGaussianBlur stdDeviation="8"/>
  </filter>
  <filter id="textLift" x="-12%" y="-30%" width="124%" height="170%">
    <feDropShadow dx="0" dy="3" stdDeviation="1.6" flood-color="#041018" flood-opacity="0.85"/>
  </filter>
`;

function satellite() {
  return `
    <g id="sat">
      <ellipse cx="120" cy="104" rx="78" ry="22" fill="#2ec4b6" opacity="0.18" filter="url(#glow)"/>
      <rect x="6" y="78" width="72" height="48" rx="7" fill="url(#panel)" stroke="#0b3a36" stroke-width="2"/>
      <g stroke="#f0b429" stroke-width="1.4" opacity="0.9">
        <line x1="14" y1="92" x2="70" y2="92"/>
        <line x1="14" y1="102" x2="70" y2="102"/>
        <line x1="14" y1="112" x2="70" y2="112"/>
      </g>
      <rect x="162" y="78" width="72" height="48" rx="7" fill="url(#panel)" stroke="#0b3a36" stroke-width="2"/>
      <g stroke="#f0b429" stroke-width="1.4" opacity="0.9">
        <line x1="170" y1="92" x2="226" y2="92"/>
        <line x1="170" y1="102" x2="226" y2="102"/>
        <line x1="170" y1="112" x2="226" y2="112"/>
      </g>
      <rect x="74" y="96" width="16" height="8" rx="2" fill="#a87412"/>
      <rect x="150" y="96" width="16" height="8" rx="2" fill="#a87412"/>
      <rect x="84" y="54" width="72" height="96" rx="20" fill="url(#gold)" stroke="#7a5410" stroke-width="2.5"/>
      <rect x="96" y="66" width="48" height="14" rx="7" fill="#fff1c2" opacity="0.35"/>
      <circle cx="120" cy="96" r="18" fill="#07141c"/>
      <circle cx="120" cy="96" r="12" fill="#14383c"/>
      <circle cx="115" cy="91" r="4.2" fill="#b8fff6"/>
      <rect x="115" y="24" width="10" height="32" rx="4" fill="#2ec4b6"/>
      <circle cx="120" cy="20" r="9" fill="#f0b429" stroke="#7a5410" stroke-width="2"/>
      <circle cx="117" cy="17" r="2.4" fill="#fff6d8"/>
      <circle cx="104" cy="132" r="4.5" fill="#0e3e42"/>
      <circle cx="136" cy="132" r="4.5" fill="#0e3e42"/>
      <circle cx="104" cy="132" r="2" fill="#7eefe6"/>
      <circle cx="136" cy="132" r="2" fill="#7eefe6"/>
    </g>`;
}

function helmet() {
  return `
    <g id="helm">
      <ellipse cx="100" cy="128" rx="62" ry="16" fill="#000" opacity="0.28" filter="url(#glow)"/>
      <path d="M36 112 C34 52 62 18 100 18 C138 18 166 52 164 112 L172 136 C176 176 146 196 100 196 C54 196 24 176 28 136 Z"
            fill="url(#gold)" stroke="#7a5410" stroke-width="2.5"/>
      <path d="M68 42 C84 28 118 26 136 46" fill="none" stroke="#fff3c9" stroke-width="5" stroke-linecap="round" opacity="0.75"/>
      <rect x="78" y="40" width="44" height="7" rx="3.5" fill="#2ec4b6"/>
      <path d="M50 104 C50 70 70 54 100 54 C130 54 150 70 150 104 L150 126 C150 144 128 154 100 154 C72 154 50 144 50 126 Z"
            fill="url(#visor)" stroke="#0b3a36" stroke-width="2"/>
      <path d="M62 96 C78 76 124 76 140 100" fill="none" stroke="#9ff7ee" stroke-width="5" stroke-linecap="round" opacity="0.9"/>
      <circle cx="30" cy="124" r="15" fill="url(#goldSoft)" stroke="#7a5410" stroke-width="2"/>
      <circle cx="170" cy="124" r="15" fill="url(#goldSoft)" stroke="#7a5410" stroke-width="2"/>
      <circle cx="30" cy="124" r="6" fill="#0e3e42"/>
      <circle cx="170" cy="124" r="6" fill="#0e3e42"/>
      <rect x="93" y="8" width="14" height="18" rx="4" fill="#2ec4b6"/>
    </g>`;
}

function ogSvg() {
  return `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="630" viewBox="0 0 1200 630">
  <defs>
    ${DEFS}
    ${satellite()}
    ${helmet()}
  </defs>
  <rect width="1200" height="630" fill="#07141c"/>
  <rect width="1200" height="630" fill="url(#sky)"/>
  <rect width="1200" height="630" fill="url(#amber)"/>
  ${stars(1200, 630, 110, 7)}
  <ellipse cx="600" cy="820" rx="760" ry="250" fill="#0c2a30"/>
  <ellipse cx="600" cy="790" rx="760" ry="210" fill="none" stroke="#2ec4b6" stroke-opacity="0.55" stroke-width="2"/>
  <rect width="1200" height="630" fill="url(#vignette)"/>
  <ellipse cx="250" cy="330" rx="120" ry="70" fill="#2ec4b6" opacity="0.16" filter="url(#glow)"/>
  <ellipse cx="980" cy="330" rx="110" ry="70" fill="#f0b429" opacity="0.14" filter="url(#glow)"/>
  <use href="#sat" transform="translate(28 188) scale(0.92)"/>
  <use href="#helm" transform="translate(968 176) scale(0.96)"/>
  <ellipse cx="600" cy="330" rx="250" ry="120" fill="#07141c" opacity="0.28"/>
  <text id="kicker" x="600" y="268" text-anchor="middle"
        font-family="Liberation Sans Narrow, Liberation Sans, sans-serif"
        font-weight="700" font-size="34" letter-spacing="12" fill="#f0b429" filter="url(#textLift)">S-7</text>
  <text id="title" x="600" y="352" text-anchor="middle"
        font-family="Liberation Sans Narrow, Liberation Sans, sans-serif"
        font-weight="700" font-size="76" letter-spacing="1.5" fill="url(#gold)" filter="url(#textLift)">STARLINK HUNTER</text>
  <text id="tag" x="600" y="404" text-anchor="middle"
        font-family="Liberation Sans, sans-serif"
        font-weight="700" font-size="18" letter-spacing="6.5" fill="#2ec4b6" filter="url(#textLift)">BILANGAN BULAT</text>
  <rect x="430" y="422" width="340" height="2" rx="1" fill="#f0b429" opacity="0.55"/>
  <rect x="28" y="22" width="1144" height="586" rx="22" fill="none" stroke="#f0b429" stroke-opacity="0.38" stroke-width="1.5"/>
</svg>`;
}

function bannerSvg() {
  return `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="264" viewBox="0 0 1200 264">
  <defs>
    ${DEFS}
    ${satellite()}
    ${helmet()}
  </defs>
  <rect width="1200" height="264" fill="#07141c"/>
  <rect width="1200" height="264" fill="url(#sky)"/>
  <rect width="1200" height="264" fill="url(#amber)"/>
  ${stars(1200, 264, 70, 21)}
  <rect width="1200" height="264" fill="url(#vignette)"/>
  <ellipse cx="860" cy="150" rx="180" ry="70" fill="#2ec4b6" opacity="0.14" filter="url(#glow)"/>
  <ellipse cx="1040" cy="140" rx="120" ry="60" fill="#f0b429" opacity="0.12" filter="url(#glow)"/>
  <use href="#sat" transform="translate(690 42) scale(0.62)"/>
  <use href="#helm" transform="translate(930 28) scale(0.7)"/>
  <ellipse cx="980" cy="300" rx="420" ry="90" fill="#0c2a30"/>
  <text id="kicker" x="56" y="62" text-anchor="start"
        font-family="Liberation Sans Narrow, Liberation Sans, sans-serif"
        font-weight="700" font-size="22" letter-spacing="7" fill="#f0b429" filter="url(#textLift)">S-7</text>
  <text id="title" x="56" y="116" text-anchor="start"
        font-family="Liberation Sans Narrow, Liberation Sans, sans-serif"
        font-weight="700" font-size="46" letter-spacing="0.8" fill="url(#gold)" filter="url(#textLift)">STARLINK HUNTER</text>
  <text id="tag" x="56" y="152" text-anchor="start"
        font-family="Liberation Sans, sans-serif"
        font-weight="700" font-size="15" letter-spacing="4.2" fill="#2ec4b6" filter="url(#textLift)">BILANGAN BULAT</text>
  <rect x="56" y="168" width="168" height="2" rx="1" fill="#f0b429" opacity="0.6"/>
</svg>`;
}

function page(svg) {
  return `<!doctype html><html><head><meta charset="utf-8"><style>
    html,body{margin:0;padding:0;background:#07141c}
    svg{display:block}
  </style></head><body>${svg}</body></html>`;
}

const browser = await chromium.launch();
const pageOg = await browser.newPage({
  viewport: { width: 1200, height: 630 },
  deviceScaleFactor: 1,
});
await pageOg.setContent(page(ogSvg()), { waitUntil: "load" });
await pageOg.evaluate(() => document.fonts.ready);
const ogBoxes = await pageOg.evaluate(() => {
  return ["kicker", "title", "tag"].map((id) => {
    const r = document.getElementById(id).getBBox();
    return { id, x: r.x, y: r.y, w: r.width, h: r.height, right: r.x + r.width, bottom: r.y + r.height };
  });
});
await pageOg.screenshot({ path: "/workspace/.grok/og-raw.png", type: "png" });

const pageBan = await browser.newPage({
  viewport: { width: 1200, height: 264 },
  deviceScaleFactor: 1,
});
await pageBan.setContent(page(bannerSvg()), { waitUntil: "load" });
await pageBan.evaluate(() => document.fonts.ready);
const banBoxes = await pageBan.evaluate(() => {
  return ["kicker", "title", "tag"].map((id) => {
    const r = document.getElementById(id).getBBox();
    return { id, x: r.x, y: r.y, w: r.width, h: r.height, right: r.x + r.width, bottom: r.y + r.height };
  });
});
await pageBan.screenshot({ path: "/workspace/.grok/x-banner-raw.png", type: "png" });

const pageIcon = await browser.newPage({
  viewport: { width: 64, height: 64 },
  deviceScaleFactor: 1,
});
await pageIcon.goto("file:///workspace/public/favicon.svg");
await pageIcon.screenshot({ path: "/workspace/.grok/favicon-64.png", type: "png" });
await browser.close();

writeFileSync(
  "/workspace/.grok/card-boxes.json",
  JSON.stringify({ og: ogBoxes, banner: banBoxes }, null, 2),
);
console.log(JSON.stringify({ og: ogBoxes, banner: banBoxes }, null, 2));
