import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Lock, c as Check, d as ArrowRight, i as RotateCcw, l as Calculator, n as Star, o as IdCard, r as Satellite, s as House, u as BookOpen } from "../_libs/lucide-react.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-1hoaB2Z5.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var CHAPTERS = [
	{
		id: 1,
		code: "Bab 01",
		title: "Kenalan dengan bilangan bulat",
		blurb: "Positif, negatif, dan nol — tiga penghuni garis angka.",
		toy: "kenal",
		lesson: [
			"Bilangan bulat adalah angka utuh: … −3, −2, −1, 0, 1, 2, 3 … Tidak ada koma.",
			"Angka lebih dari nol disebut positif. Angka kurang dari nol disebut negatif. Nol bukan positif dan bukan negatif, tapi tetap bilangan bulat.",
			"Lawan dari 5 adalah −5. Lawan dari −5 adalah 5. Keduanya sama jauh dari nol."
		],
		questions: [
			{
				prompt: "Mana yang bukan bilangan bulat?",
				choices: [
					"4",
					"−9",
					"0",
					"3,5"
				],
				answer: 3,
				why: "3,5 punya koma, jadi pecahan. Bilangan bulat selalu utuh."
			},
			{
				prompt: "Lawan dari −6 adalah …",
				choices: [
					"−6",
					"0",
					"6",
					"12"
				],
				answer: 2,
				why: "Lawan sebuah bilangan adalah angka yang sama jauhnya di sisi lain nol."
			},
			{
				prompt: "Urutan dari yang terkecil, mana yang benar?",
				choices: [
					"2, 0, −1, −3",
					"−3, −1, 0, 2",
					"0, −3, −1, 2",
					"−1, −3, 0, 2"
				],
				answer: 1,
				why: "Di garis bilangan, yang lebih kiri selalu lebih kecil."
			},
			{
				prompt: "Bilangan bulat negatif berada di … nol.",
				choices: [
					"kanan",
					"kiri",
					"atas",
					"dalam"
				],
				answer: 1,
				why: "Negatif di kiri nol, positif di kanan nol."
			},
			{
				prompt: "Nol termasuk …",
				choices: [
					"bilangan positif",
					"bilangan negatif",
					"bilangan bulat",
					"pecahan"
				],
				answer: 2,
				why: "Nol adalah bilangan bulat. Ia bukan positif dan bukan negatif."
			}
		]
	},
	{
		id: 2,
		code: "Bab 02",
		title: "Garis bilangan",
		blurb: "Geser ke kanan berarti bertambah. Geser ke kiri berarti berkurang.",
		toy: "garis",
		lesson: [
			"Garis bilangan adalah peta semua bilangan bulat. Nol di tengah.",
			"Melangkah ke kanan menambah. Melangkah ke kiri mengurangi.",
			"Jarak dua angka adalah selisihnya, selalu dihitung positif. Dari −2 ke 3 ada 5 langkah."
		],
		questions: [
			{
				prompt: "Angka di sebelah kanan selalu lebih …",
				choices: [
					"kecil",
					"besar",
					"genap",
					"negatif"
				],
				answer: 1,
				why: "Makin ke kanan, nilainya makin besar."
			},
			{
				prompt: "Jarak dari −2 ke 3 adalah …",
				choices: [
					"1",
					"5",
					"6",
					"−5"
				],
				answer: 1,
				why: "Dari −2 ke 0 ada 2 langkah, lalu ke 3 ada 3 langkah. Total 5."
			},
			{
				prompt: "Empat langkah ke kiri dari 1 mendarat di …",
				choices: [
					"5",
					"−3",
					"−4",
					"3"
				],
				answer: 1,
				why: "1 − 4 = −3."
			},
			{
				prompt: "Ada berapa bilangan bulat di antara −1 dan 2?",
				choices: [
					"1",
					"2",
					"3",
					"4"
				],
				answer: 1,
				why: "Yang di tengah, tidak termasuk ujungnya, hanya 0 dan 1."
			},
			{
				prompt: "Mana yang lebih dekat ke nol?",
				choices: [
					"−8",
					"6",
					"keduanya sama",
					"tidak bisa dibanding"
				],
				answer: 1,
				why: "Jarak −8 adalah 8. Jarak 6 adalah 6. Enam lebih dekat."
			}
		]
	},
	{
		id: 3,
		code: "Bab 03",
		title: "Tambah dan kurang",
		blurb: "Menggabungkan langkah kanan dan kiri.",
		toy: "hitung",
		lesson: [
			"Menambah bilangan positif sama dengan melangkah ke kanan. Menambah bilangan negatif sama dengan melangkah ke kiri.",
			"Mengurangi sama dengan berjalan ke arah sebaliknya. 4 − (−6) berarti 4 ditambah 6, hasilnya 10.",
			"Urutan hitung dari kiri ke kanan jika hanya ada tambah dan kurang."
		],
		questions: [
			{
				prompt: "7 + (−4) = …",
				choices: [
					"11",
					"3",
					"−3",
					"−11"
				],
				answer: 1,
				why: "Mulai di 7, lalu 4 langkah ke kiri. Mendarat di 3."
			},
			{
				prompt: "−5 + (−3) = …",
				choices: [
					"−8",
					"−2",
					"8",
					"2"
				],
				answer: 0,
				why: "Dua langkah ke kiri digabung: −5 dan −3 menjadi −8."
			},
			{
				prompt: "4 − (−6) = …",
				choices: [
					"−2",
					"2",
					"10",
					"−10"
				],
				answer: 2,
				why: "Mengurangi negatif sama dengan menambah. 4 + 6 = 10."
			},
			{
				prompt: "−9 − 2 = …",
				choices: [
					"−7",
					"−11",
					"11",
					"7"
				],
				answer: 1,
				why: "Dari −9, langkah 2 lagi ke kiri. Hasilnya −11."
			},
			{
				prompt: "−3 + 8 + (−1) = …",
				choices: [
					"4",
					"6",
					"−12",
					"10"
				],
				answer: 0,
				why: "−3 + 8 = 5, lalu 5 + (−1) = 4."
			}
		]
	},
	{
		id: 4,
		code: "Bab 04",
		title: "Kali dan bagi",
		blurb: "Aturan tanda: sama-sama hasilnya positif, beda hasilnya negatif.",
		toy: "tanda",
		lesson: [
			"Positif kali positif = positif. Negatif kali negatif = positif. Tanda beda = negatif.",
			"Pembagian memakai aturan tanda yang sama. Nol kali apa pun tetap nol.",
			"Tidak bisa membagi dengan nol. Di latihan ini pembagi selalu bukan nol."
		],
		questions: [
			{
				prompt: "(−4) × 5 = …",
				choices: [
					"20",
					"−20",
					"9",
					"−1"
				],
				answer: 1,
				why: "Tanda beda, jadi negatif. 4 × 5 = 20, hasilnya −20."
			},
			{
				prompt: "(−3) × (−6) = …",
				choices: [
					"−18",
					"−9",
					"18",
					"9"
				],
				answer: 2,
				why: "Negatif kali negatif menghasilkan positif. 3 × 6 = 18."
			},
			{
				prompt: "12 ÷ (−3) = …",
				choices: [
					"4",
					"−4",
					"9",
					"−9"
				],
				answer: 1,
				why: "12 ÷ 3 = 4, tandanya beda, jadi −4."
			},
			{
				prompt: "(−24) ÷ (−8) = …",
				choices: [
					"−3",
					"3",
					"−16",
					"32"
				],
				answer: 1,
				why: "Tanda sama-sama negatif, hasilnya positif. 24 ÷ 8 = 3."
			},
			{
				prompt: "0 × (−15) = …",
				choices: [
					"−15",
					"15",
					"0",
					"1"
				],
				answer: 2,
				why: "Nol kali bilangan apa pun tetap nol."
			}
		]
	},
	{
		id: 5,
		code: "Bab 05",
		title: "Bandingkan dan nilai mutlak",
		blurb: "Mana lebih besar, dan seberapa jauh dari nol.",
		toy: "mutlak",
		lesson: [
			"Untuk membandingkan, lihat posisinya di garis. Yang lebih kanan lebih besar. −2 lebih besar dari −9.",
			"Nilai mutlak |n| adalah jarak n ke nol. Selalu nol atau positif. |−9| = 9 dan |9| = 9.",
			"Dua angka bisa sama jauh dari nol tapi beda tanda."
		],
		questions: [
			{
				prompt: "Pernyataan yang benar adalah …",
				choices: [
					"−7 > −2",
					"−7 < −2",
					"−7 = −2",
					"−2 < −7"
				],
				answer: 1,
				why: "−7 lebih kiri, jadi lebih kecil daripada −2."
			},
			{
				prompt: "Nilai mutlak |−9| = …",
				choices: [
					"−9",
					"0",
					"9",
					"18"
				],
				answer: 2,
				why: "Jarak −9 ke nol adalah 9."
			},
			{
				prompt: "|−3| dibanding |3| …",
				choices: [
					"lebih kecil",
					"lebih besar",
					"sama dengan",
					"tidak ada"
				],
				answer: 2,
				why: "Keduanya berjarak 3 dari nol."
			},
			{
				prompt: "Yang paling besar di antara 4, −1, dan −6 adalah …",
				choices: [
					"−6",
					"−1",
					"4",
					"semua sama"
				],
				answer: 2,
				why: "4 satu-satunya yang positif, jadi paling kanan."
			},
			{
				prompt: "−10 … −4",
				choices: [
					"lebih besar dari",
					"sama dengan",
					"lebih kecil dari",
					"bukan bilangan bulat"
				],
				answer: 2,
				why: "−10 lebih kiri dari −4, jadi lebih kecil."
			}
		]
	},
	{
		id: 6,
		code: "Bab 06",
		title: "Ujian Hunter",
		blurb: "Gabungan semua bab. Lulus ini, kamu kadet hitung Sayap S-7.",
		toy: "hitung",
		lesson: [
			"Ujian ini mencampur tambah, kurang, kali, bagi, dan nilai mutlak.",
			"Kerjakan tanda kurung dan kali-bagi lebih dulu, baru tambah-kurang.",
			"Kalau ragu, gambar garis bilangan kecil di kertas. Tiga bintang artinya semua benar."
		],
		questions: [
			{
				prompt: "−6 + 9 − (−2) = …",
				choices: [
					"1",
					"5",
					"−17",
					"17"
				],
				answer: 1,
				why: "−6 + 9 = 3, lalu 3 − (−2) = 3 + 2 = 5."
			},
			{
				prompt: "(−5) × (−2) + (−4) = …",
				choices: [
					"6",
					"14",
					"−6",
					"−14"
				],
				answer: 0,
				why: "(−5) × (−2) = 10, lalu 10 + (−4) = 6."
			},
			{
				prompt: "18 ÷ (−2) − 3 = …",
				choices: [
					"−6",
					"−12",
					"12",
					"6"
				],
				answer: 1,
				why: "18 ÷ (−2) = −9, lalu −9 − 3 = −12."
			},
			{
				prompt: "Nilai mutlak dari −8 + 3 adalah …",
				choices: [
					"−5",
					"5",
					"11",
					"−11"
				],
				answer: 1,
				why: "−8 + 3 = −5, dan |−5| = 5."
			},
			{
				prompt: "Hasil mana yang paling besar?",
				choices: [
					"−3 × 4",
					"−20 ÷ 5",
					"2 + (−7)",
					"−1 − (−6)"
				],
				answer: 3,
				why: "Hasilnya berturut-turut −12, −4, −5, dan 5. Lima yang terbesar."
			}
		]
	}
];
function chapterById(id) {
	return CHAPTERS.find((chapter) => chapter.id === id) ?? CHAPTERS[0];
}
function rand(min, max) {
	return min + Math.floor(Math.random() * (max - min + 1));
}
function shuffle(values) {
	const list = [...values];
	for (let index = list.length - 1; index > 0; index -= 1) {
		const swap = Math.floor(Math.random() * (index + 1));
		const current = list[index] ?? 0;
		list[index] = list[swap] ?? 0;
		list[swap] = current;
	}
	return list;
}
function choicesFor(answer) {
	const bag = /* @__PURE__ */ new Set([answer]);
	for (const offset of [
		1,
		-1,
		2,
		-2,
		3,
		-3,
		4,
		-4,
		5,
		-5,
		10,
		-10
	]) {
		if (bag.size >= 4) break;
		bag.add(answer + offset);
	}
	return shuffle([...bag]);
}
function makeProblem(level, op) {
	const span = level === "mudah" ? 8 : 16;
	if (op === "bagi") {
		const divisorMag = rand(1, level === "mudah" ? 6 : 9);
		const divisor = Math.random() < .5 ? -divisorMag : divisorMag;
		const quotient = rand(-span, span) || 1;
		return {
			prompt: `${quotient * divisor} ÷ (${divisor})`,
			answer: quotient,
			choices: choicesFor(quotient)
		};
	}
	const left = rand(-span, span);
	const right = rand(-span, span);
	if (op === "kurang") return {
		prompt: `${left} − (${right})`,
		answer: left - right,
		choices: choicesFor(left - right)
	};
	if (op === "kali") {
		const a = rand(-Math.min(span, 9), Math.min(span, 9));
		const b = rand(-Math.min(span, 9), Math.min(span, 9));
		return {
			prompt: `(${a}) × (${b})`,
			answer: a * b,
			choices: choicesFor(a * b)
		};
	}
	return {
		prompt: `${left} + (${right})`,
		answer: left + right,
		choices: choicesFor(left + right)
	};
}
var useAcademy = create()(persist((set, get) => ({
	best: {},
	biodata: null,
	view: "markas",
	chapterId: 1,
	phase: "belajar",
	qIndex: 0,
	picked: null,
	correctCount: 0,
	attempt: null,
	openView: (view) => set({ view }),
	openChapter: (id) => set({
		view: "bab",
		chapterId: id,
		phase: "belajar",
		qIndex: 0,
		picked: null,
		correctCount: 0,
		attempt: null
	}),
	setPhase: (phase) => set(phase === "hasil" ? { phase } : {
		phase,
		qIndex: 0,
		picked: null,
		correctCount: 0
	}),
	pick: (index, isCorrect) => {
		if (get().picked !== null) return;
		set((state) => ({
			picked: index,
			correctCount: state.correctCount + (isCorrect ? 1 : 0)
		}));
	},
	nextQuestion: (total) => {
		const { qIndex, correctCount, chapterId, best } = get();
		if (qIndex + 1 >= total) {
			const stars = starsFor(correctCount, total);
			const prev = best[chapterId];
			const nextBest = !prev || correctCount > prev.correct ? {
				correct: correctCount,
				stars
			} : prev;
			set({
				phase: "hasil",
				picked: null,
				attempt: {
					correct: correctCount,
					stars
				},
				best: {
					...best,
					[chapterId]: nextBest
				}
			});
			return;
		}
		set({
			qIndex: qIndex + 1,
			picked: null
		});
	},
	restartQuiz: () => set({
		phase: "soal",
		qIndex: 0,
		picked: null,
		correctCount: 0
	}),
	saveBiodata: (biodata) => set({ biodata }),
	clearBiodata: () => set({ biodata: null })
}), {
	name: "s7-starlink-hunter",
	storage: createJSONStorage(() => typeof window === "undefined" ? {
		getItem: () => null,
		setItem: () => {},
		removeItem: () => {}
	} : localStorage),
	partialize: (state) => ({
		best: state.best,
		biodata: state.biodata
	}),
	skipHydration: true
}));
function starsFor(correct, total) {
	if (total <= 0) return 0;
	const ratio = correct / total;
	if (ratio >= 1) return 3;
	if (ratio >= .8) return 2;
	if (ratio >= .6) return 1;
	return 0;
}
function isUnlocked(id, best) {
	if (id <= 1) return true;
	return (best[id - 1]?.stars ?? 0) >= 1;
}
function callsign(nama, favorit) {
	const words = [
		"ORBIT",
		"AURORA",
		"NOVA",
		"PULSAR",
		"COMET",
		"LYRA"
	];
	let hash = 0;
	const source = nama.trim().toUpperCase() || "KADET";
	for (const char of source) hash = (hash * 33 + char.charCodeAt(0)) % 997;
	return `${words[Math.abs(hash) % words.length] ?? "ORBIT"}-${Math.abs((hash + favorit * 7) % 90) + 10}`;
}
function clearedCount(best) {
	return Object.values(best).filter((item) => item.stars >= 1).length;
}
function starTotal(best) {
	return Object.values(best).reduce((sum, item) => sum + item.stars, 0);
}
var LINE = [
	-6,
	-5,
	-4,
	-3,
	-2,
	-1,
	0,
	1,
	2,
	3,
	4,
	5,
	6
];
function describe(n) {
	if (n > 0) return `${n} positif. Letaknya ${n} langkah di kanan nol.`;
	if (n < 0) return `${n} negatif. Letaknya ${Math.abs(n)} langkah di kiri nol.`;
	return "Nol tepat di tengah. Bukan positif, bukan negatif.";
}
function LessonToy({ toy }) {
	if (toy === "kenal") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kenal, {});
	if (toy === "garis") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Garis, {});
	if (toy === "hitung") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hitung, {});
	if (toy === "tanda") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tanda, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mutlak, {});
}
function Kenal() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-3 gap-2",
		children: [
			{
				n: "−3",
				label: "Negatif",
				note: "Di kiri nol"
			},
			{
				n: "0",
				label: "Nol",
				note: "Titik tengah"
			},
			{
				n: "+5",
				label: "Positif",
				note: "Di kanan nol"
			}
		].map((card) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-control bg-raised px-2 py-3 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-2xl tabular-nums text-accent",
					children: card.n
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm font-semibold",
					children: card.label
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted",
					children: card.note
				})
			]
		}, card.n))
	});
}
function Garis() {
	const [picked, setPicked] = (0, import_react.useState)(0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex flex-wrap justify-center gap-1",
		children: LINE.map((n) => {
			const on = n === picked;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setPicked(n),
				className: "size-11 rounded-control text-sm font-semibold tabular-nums " + (on ? "bg-primary text-primary-fg" : "bg-raised text-fg"),
				"aria-pressed": on,
				children: n
			}, n);
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mt-3 text-sm text-muted",
		children: describe(picked)
	})] });
}
function Hitung() {
	const [left, setLeft] = (0, import_react.useState)(4);
	const [right, setRight] = (0, import_react.useState)(-2);
	const [minus, setMinus] = (0, import_react.useState)(false);
	const result = minus ? left - right : left + right;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-end gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
					label: "Angka pertama",
					value: left,
					onChange: setLeft
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-1 pb-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setMinus(false),
						className: "h-11 rounded-control px-3 font-semibold " + (!minus ? "bg-primary text-primary-fg" : "bg-raised text-fg"),
						children: "tambah"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setMinus(true),
						className: "h-11 rounded-control px-3 font-semibold " + (minus ? "bg-primary text-primary-fg" : "bg-raised text-fg"),
						children: "kurang"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
					label: "Angka kedua",
					value: right,
					onChange: setRight
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "font-display text-2xl tabular-nums",
			children: [
				left,
				" ",
				minus ? "−" : "+",
				" (",
				right,
				") = ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-accent",
					children: result
				})
			]
		})]
	});
}
function Tanda() {
	const [leftNeg, setLeftNeg] = (0, import_react.useState)(true);
	const [rightNeg, setRightNeg] = (0, import_react.useState)(false);
	const productNeg = leftNeg !== rightNeg;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignToggle, {
					label: "Angka A",
					negative: leftNeg,
					onChange: setLeftNeg
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignToggle, {
					label: "Angka B",
					negative: rightNeg,
					onChange: setRightNeg
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: productNeg ? "Tandanya beda, jadi hasil kali negatif." : "Tandanya sama, jadi hasil kali positif."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "font-display text-xl",
				children: [
					"Hasil:",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-accent",
						children: productNeg ? "negatif" : "positif"
					})
				]
			})
		]
	});
}
function Mutlak() {
	const [n, setN] = (0, import_react.useState)(-4);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
			label: "Pilih angka",
			value: n,
			onChange: setN,
			min: -9,
			max: 9
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-3 font-display text-2xl tabular-nums",
			children: [
				"|",
				n,
				"| = ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-accent",
					children: Math.abs(n)
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 h-3 overflow-hidden rounded-full bg-raised",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-full rounded-full bg-primary",
				style: { width: `${Math.abs(n) / 9 * 100}%` }
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-muted",
			children: "Batang ini menunjukkan jarak ke nol, tanpa tanda."
		})
	] });
}
function Stepper({ label, value, onChange, min = -8, max = 8 }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mb-1 text-xs font-semibold tracking-wide text-muted uppercase",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "size-11 rounded-control bg-raised text-lg font-semibold",
				onClick: () => onChange(Math.max(min, value - 1)),
				"aria-label": `Kurangi ${label}`,
				children: "−"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "w-10 text-center font-display text-2xl tabular-nums",
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "size-11 rounded-control bg-raised text-lg font-semibold",
				onClick: () => onChange(Math.min(max, value + 1)),
				"aria-label": `Tambah ${label}`,
				children: "+"
			})
		]
	})] });
}
function SignToggle({ label, negative, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-control bg-raised px-3 py-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs font-semibold tracking-wide text-muted uppercase",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-1 flex gap-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => onChange(false),
				className: "h-11 rounded-control px-3 font-semibold " + (!negative ? "bg-primary text-primary-fg" : "text-fg"),
				children: "positif"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => onChange(true),
				className: "h-11 rounded-control px-3 font-semibold " + (negative ? "bg-accent text-accent-fg" : "text-fg"),
				children: "negatif"
			})]
		})]
	});
}
function Markas() {
	const biodata = useAcademy((s) => s.biodata);
	const best = useAcademy((s) => s.best);
	const openChapter = useAcademy((s) => s.openChapter);
	const openView = useAcademy((s) => s.openView);
	const resume = CHAPTERS.find((chapter) => isUnlocked(chapter.id, best) && (best[chapter.id]?.stars ?? 0) < 1) ?? CHAPTERS[CHAPTERS.length - 1];
	const name = biodata?.panggilan || biodata?.nama || "Kadet";
	const stars = starTotal(best);
	const done = clearedCount(best);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rise grid gap-5 md:grid-cols-[1.15fr_0.85fr] md:items-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold tracking-widest text-primary uppercase",
				children: "Sayap S-7 · Starlink"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
				className: "mt-2 font-display text-4xl text-fg",
				children: [
					"Halo, ",
					name,
					"."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-md text-muted",
				children: "Akademi Hunter untuk bilangan bulat. Selesaikan bab, kumpulkan bintang, lalu cetak kartu kadetmu di Mesin Biodata B."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Bab lulus",
						value: `${done}/6`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Bintang",
						value: `${stars}/18`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Kode",
						value: biodata ? callsign(biodata.nama, biodata.favorit) : "—"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => openChapter(resume.id),
					className: "inline-flex h-12 items-center gap-2 rounded-control bg-accent px-4 font-semibold text-accent-fg",
					children: [done === 0 ? "Mulai Bab 1" : `Lanjut ${resume.code}`, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
						className: "size-4",
						"aria-hidden": "true"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => openView("biodata"),
					className: "inline-flex h-12 items-center rounded-control bg-raised px-4 font-semibold text-fg",
					children: "Mesin Biodata B"
				})]
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
			className: "panel overflow-hidden",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/academy/cadet.jpg",
				alt: "Kadet muda berhelm teal berdiri di samping satelit kecil",
				className: "aspect-square w-full object-cover"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figcaption", {
				className: "flex items-center gap-2 px-4 py-3 text-sm text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Satellite, {
					className: "size-4 text-primary",
					"aria-hidden": "true"
				}), "Satelit kecil menemani setiap misi hitung."]
			})]
		})]
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-w-24 rounded-control bg-surface px-3 py-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-lg tabular-nums",
			children: value
		})]
	});
}
function PetaBab() {
	const best = useAcademy((s) => s.best);
	const openChapter = useAcademy((s) => s.openChapter);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rise",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl",
				children: "Peta bab"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-muted",
				children: "Bab berikutnya terbuka setelah kamu meraih minimal satu bintang."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-4 space-y-2",
				children: CHAPTERS.map((chapter) => {
					const open = isUnlocked(chapter.id, best);
					const record = best[chapter.id];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						disabled: !open,
						onClick: () => openChapter(chapter.id),
						className: "panel flex w-full items-center gap-3 px-4 py-3 text-left disabled:opacity-50",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid size-11 shrink-0 place-items-center rounded-control bg-raised font-display text-primary",
								children: open ? chapter.id : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, {
									className: "size-4",
									"aria-hidden": "true"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-xs font-semibold tracking-wide text-muted uppercase",
									children: chapter.code
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block font-semibold",
									children: chapter.title
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stars, { count: record?.stars ?? 0 })
						]
					}) }, chapter.id);
				})
			})
		]
	});
}
function BabScreen() {
	const chapterId = useAcademy((s) => s.chapterId);
	const phase = useAcademy((s) => s.phase);
	const setPhase = useAcademy((s) => s.setPhase);
	const openView = useAcademy((s) => s.openView);
	const chapter = chapterById(chapterId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rise",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => openView("peta"),
				className: "text-sm font-semibold text-primary",
				children: "Kembali ke peta"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-xs font-semibold tracking-widest text-primary uppercase",
				children: chapter.code
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 font-display text-3xl",
				children: chapter.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-muted",
				children: chapter.blurb
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 grid grid-cols-3 gap-1 rounded-control bg-surface p-1",
				children: [
					["belajar", "Pelajaran"],
					["soal", "Soal"],
					["hasil", "Nilai"]
				].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setPhase(id),
					className: "h-11 rounded-control text-sm font-semibold " + (phase === id ? "bg-primary text-primary-fg" : "text-muted"),
					children: label
				}, id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4",
				children: [
					phase === "belajar" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Belajar, { chapter }) : null,
					phase === "soal" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Soal, { chapter }) : null,
					phase === "hasil" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hasil, { chapter }) : null
				]
			})
		]
	});
}
function Belajar({ chapter }) {
	const setPhase = useAcademy((s) => s.setPhase);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			chapter.lesson.map((paragraph) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: paragraph }, paragraph)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "panel p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-3 text-xs font-semibold tracking-widest text-accent uppercase",
					children: "Meja latihan"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LessonToy, { toy: chapter.toy })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => setPhase("soal"),
				className: "inline-flex h-12 items-center gap-2 rounded-control bg-accent px-4 font-semibold text-accent-fg",
				children: ["Kerjakan 5 soal", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
					className: "size-4",
					"aria-hidden": "true"
				})]
			})
		]
	});
}
function Soal({ chapter }) {
	const qIndex = useAcademy((s) => s.qIndex);
	const picked = useAcademy((s) => s.picked);
	const pick = useAcademy((s) => s.pick);
	const nextQuestion = useAcademy((s) => s.nextQuestion);
	const question = chapter.questions[qIndex];
	if (!question) return null;
	const revealed = picked !== null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "panel p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs font-semibold tracking-wide text-muted uppercase",
				children: [
					"Soal ",
					qIndex + 1,
					" dari ",
					chapter.questions.length
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-2 font-display text-2xl",
				children: question.prompt
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 grid gap-2",
				children: question.choices.map((choice, index) => {
					const selected = picked === index;
					const correct = index === question.answer;
					let tone = "bg-raised text-fg";
					if (revealed && correct) tone = "bg-primary text-primary-fg";
					else if (revealed && selected) tone = "bg-accent text-accent-fg";
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						disabled: revealed,
						onClick: () => pick(index, correct),
						className: `min-h-12 rounded-control px-4 py-3 text-left font-semibold ${tone}`,
						children: choice
					}, choice);
				})
			}),
			revealed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-semibold",
						children: picked === question.answer ? "Tepat." : "Belum tepat."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: question.why
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => nextQuestion(chapter.questions.length),
						className: "mt-3 inline-flex h-12 items-center gap-2 rounded-control bg-primary px-4 font-semibold text-primary-fg",
						children: [qIndex + 1 === chapter.questions.length ? "Lihat nilai" : "Lanjut", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
							className: "size-4",
							"aria-hidden": "true"
						})]
					})
				]
			}) : null
		]
	});
}
function Hasil({ chapter }) {
	const attempt = useAcademy((s) => s.attempt);
	const best = useAcademy((s) => s.best);
	const restartQuiz = useAcademy((s) => s.restartQuiz);
	const openChapter = useAcademy((s) => s.openChapter);
	const record = best[chapter.id];
	const passed = (record?.stars ?? 0) >= 1;
	const next = CHAPTERS.find((item) => item.id === chapter.id + 1);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "panel p-4",
		children: [
			attempt ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold tracking-widest text-muted uppercase",
					children: "Hasil kali ini"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 font-display text-4xl tabular-nums",
					children: [attempt.correct, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-xl text-muted",
						children: ["/", chapter.questions.length]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stars, { count: attempt.stars })
				})
			] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Kerjakan soal dulu supaya nilainya muncul di sini." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-sm text-muted",
				children: [
					"Rekor bab ini: ",
					record ? `${record.correct}/${chapter.questions.length}` : "belum ada",
					".",
					" ",
					passed ? "Bab ini lulus. Satu bintang sudah cukup untuk membuka bab berikut." : "Butuh minimal 3 benar dari 5 soal supaya bab berikut terbuka."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: restartQuiz,
					className: "inline-flex h-12 items-center gap-2 rounded-control bg-raised px-4 font-semibold",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {
						className: "size-4",
						"aria-hidden": "true"
					}), "Ulangi soal"]
				}), next && passed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => openChapter(next.id),
					className: "inline-flex h-12 items-center gap-2 rounded-control bg-accent px-4 font-semibold text-accent-fg",
					children: [next.code, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
						className: "size-4",
						"aria-hidden": "true"
					})]
				}) : null]
			})
		]
	});
}
var OPS = [
	{
		id: "tambah",
		label: "Tambah"
	},
	{
		id: "kurang",
		label: "Kurang"
	},
	{
		id: "kali",
		label: "Kali"
	},
	{
		id: "bagi",
		label: "Bagi"
	}
];
function Latihan() {
	const [level, setLevel] = (0, import_react.useState)("mudah");
	const [op, setOp] = (0, import_react.useState)("tambah");
	const [problem, setProblem] = (0, import_react.useState)(null);
	const [picked, setPicked] = (0, import_react.useState)(null);
	const [streak, setStreak] = (0, import_react.useState)(0);
	const [seen, setSeen] = (0, import_react.useState)(0);
	const [right, setRight] = (0, import_react.useState)(0);
	function fresh(nextLevel = level, nextOp = op) {
		setProblem(makeProblem(nextLevel, nextOp));
		setPicked(null);
		setSeen((count) => count + 1);
	}
	function choose(value) {
		if (!problem || picked !== null) return;
		setPicked(value);
		if (value === problem.answer) {
			setRight((count) => count + 1);
			setStreak((count) => count + 1);
		} else setStreak(0);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rise",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl",
				children: "Mesin latihan"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-muted",
				children: "Soal baru tiap kali. Tidak ada waktu, jadi hitung dengan tenang."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 flex flex-wrap gap-2",
				children: OPS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => {
						setOp(item.id);
						if (problem) fresh(level, item.id);
					},
					className: "h-11 rounded-control px-3 text-sm font-semibold " + (op === item.id ? "bg-primary text-primary-fg" : "bg-surface text-fg"),
					children: item.label
				}, item.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 flex gap-2",
				children: ["mudah", "sedang"].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => {
						setLevel(item);
						if (problem) fresh(item, op);
					},
					className: "h-11 rounded-control px-3 text-sm font-semibold capitalize " + (level === item ? "bg-accent text-accent-fg" : "bg-surface text-fg"),
					children: item
				}, item))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex gap-4 text-sm text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "tabular-nums",
						children: ["Benar ", right]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "tabular-nums",
						children: ["Soal ", seen]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "tabular-nums",
						children: ["Runtut ", streak]
					})
				]
			}),
			problem ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "panel mt-4 p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-3xl tabular-nums",
						children: problem.prompt
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 grid grid-cols-2 gap-2",
						children: problem.choices.map((choice) => {
							const revealed = picked !== null;
							const selected = picked === choice;
							const correct = choice === problem.answer;
							let tone = "bg-raised text-fg";
							if (revealed && correct) tone = "bg-primary text-primary-fg";
							else if (revealed && selected) tone = "bg-accent text-accent-fg";
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								disabled: revealed,
								onClick: () => choose(choice),
								className: `h-14 rounded-control font-display text-xl tabular-nums ${tone}`,
								children: choice
							}, choice);
						})
					}),
					picked !== null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => fresh(),
						className: "mt-4 inline-flex h-12 items-center gap-2 rounded-control bg-primary px-4 font-semibold text-primary-fg",
						children: ["Soal berikut", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
							className: "size-4",
							"aria-hidden": "true"
						})]
					}) : null
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => fresh(),
				className: "mt-5 inline-flex h-12 items-center gap-2 rounded-control bg-accent px-4 font-semibold text-accent-fg",
				children: ["Mulai soal", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
					className: "size-4",
					"aria-hidden": "true"
				})]
			})
		]
	});
}
var EMPTY_FORM = {
	nama: "",
	panggilan: "",
	umur: "11",
	kelas: "",
	sekolah: "",
	favorit: "",
	hobi: "",
	cita: "",
	skuad: "ombak"
};
function BiodataScreen() {
	const saved = useAcademy((s) => s.biodata);
	const saveBiodata = useAcademy((s) => s.saveBiodata);
	const clearBiodata = useAcademy((s) => s.clearBiodata);
	const [form, setForm] = (0, import_react.useState)(() => saved ? toForm(saved) : EMPTY_FORM);
	const [error, setError] = (0, import_react.useState)("");
	const [confirmClear, setConfirmClear] = (0, import_react.useState)(false);
	const [printed, setPrinted] = (0, import_react.useState)(saved);
	(0, import_react.useEffect)(() => {
		const apply = () => {
			const data = useAcademy.getState().biodata;
			if (!data) return;
			setForm(toForm(data));
			setPrinted(data);
		};
		const unsub = useAcademy.persist.onFinishHydration(apply);
		if (useAcademy.persist.hasHydrated()) apply();
		return unsub;
	}, []);
	function update(key, value) {
		setForm((current) => ({
			...current,
			[key]: value
		}));
	}
	function onSubmit(event) {
		event.preventDefault();
		const nama = form.nama.trim();
		const umur = Number(form.umur);
		const favorit = parseInteger(form.favorit);
		if (nama.length < 2) {
			setError("Isi nama, minimal 2 huruf.");
			return;
		}
		if (!Number.isInteger(umur) || umur < 5 || umur > 99) {
			setError("Umur diisi angka utuh, dari 5 sampai 99.");
			return;
		}
		if (favorit === null) {
			setError("Bilangan favorit harus bilangan bulat, misalnya 7 atau −4.");
			return;
		}
		if (form.hobi.trim().length < 2 || form.cita.trim().length < 2) {
			setError("Isi hobi dan cita-cita.");
			return;
		}
		const next = {
			nama,
			panggilan: form.panggilan.trim() || nama.split(" ")[0] || nama,
			umur,
			kelas: form.kelas.trim() || "—",
			sekolah: form.sekolah.trim(),
			favorit,
			hobi: form.hobi.trim(),
			cita: form.cita.trim(),
			skuad: form.skuad
		};
		saveBiodata(next);
		setPrinted(next);
		setError("");
		setConfirmClear(false);
	}
	const card = printed ?? saved;
	const previewSign = (0, import_react.useMemo)(() => card ? callsign(card.nama, card.favorit) : "", [card]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rise grid gap-5 lg:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl",
				children: "Mesin Biodata B"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-muted",
				children: "Isi data kamu sendiri. Kartu hanya tersimpan di perangkat ini, bukan data orang lain."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit,
				className: "mt-4 space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Nama",
						value: form.nama,
						onChange: (value) => update("nama", value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Nama panggilan",
						value: form.panggilan,
						onChange: (value) => update("panggilan", value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Umur",
							value: form.umur,
							onChange: (value) => update("umur", value),
							inputMode: "numeric"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Kelas",
							value: form.kelas,
							onChange: (value) => update("kelas", value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Sekolah",
						value: form.sekolah,
						onChange: (value) => update("sekolah", value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Bilangan bulat favorit",
						value: form.favorit,
						onChange: (value) => update("favorit", value),
						inputMode: "text"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Hobi",
						value: form.hobi,
						onChange: (value) => update("hobi", value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Cita-cita",
						value: form.cita,
						onChange: (value) => update("cita", value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
						className: "mb-1 text-xs font-semibold tracking-wide text-muted uppercase",
						children: "Skuad"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex gap-2",
						children: [["ombak", "Ombak"], ["surya", "Surya"]].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => update("skuad", id),
							className: "h-11 flex-1 rounded-control font-semibold " + (form.skuad === id ? id === "surya" ? "bg-accent text-accent-fg" : "bg-primary text-primary-fg" : "bg-surface text-fg"),
							children: label
						}, id))
					})] }),
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-semibold text-accent",
						children: error
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "submit",
						className: "inline-flex h-12 items-center gap-2 rounded-control bg-accent px-4 font-semibold text-accent-fg",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
							className: "size-4",
							"aria-hidden": "true"
						}), "Cetak kartu"]
					})
				]
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [card ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "panel overflow-hidden " + (card.skuad === "surya" ? "skuad-surya" : "skuad-ombak"),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between bg-raised px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold tracking-widest uppercase",
					children: "Kartu kadet · Seri B"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Satellite, {
					className: "size-4 text-primary",
					"aria-hidden": "true"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3 p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-3xl",
						children: card.panggilan
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-muted",
						children: card.nama
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "grid grid-cols-2 gap-3 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
								label: "Umur",
								value: `${card.umur} tahun`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
								label: "Kelas",
								value: card.kelas
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
								label: "Sekolah",
								value: card.sekolah || "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
								label: "Skuad",
								value: card.skuad === "surya" ? "Surya" : "Ombak"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
								label: "Bilangan favorit",
								value: String(card.favorit)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
								label: "Kode",
								value: previewSign
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs font-semibold tracking-wide text-muted uppercase",
						children: "Hobi"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-1 block",
						children: card.hobi
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs font-semibold tracking-wide text-muted uppercase",
						children: "Cita-cita"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-1 block",
						children: card.cita
					})] })
				]
			})]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "panel grid min-h-64 place-items-center p-6 text-center",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Satellite, {
					className: "mx-auto size-8 text-primary",
					"aria-hidden": "true"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 font-semibold",
					children: "Mesin masih kosong"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Cetak kartu setelah formulir terisi."
				})
			] })
		}), saved ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: () => {
				if (!confirmClear) {
					setConfirmClear(true);
					return;
				}
				clearBiodata();
				setPrinted(null);
				setForm(EMPTY_FORM);
				setConfirmClear(false);
			},
			className: "mt-3 h-11 text-sm font-semibold text-muted",
			children: confirmClear ? "Yakin hapus kartu ini?" : "Hapus kartu di perangkat ini"
		}) : null] })]
	});
}
function Field({ label, value, onChange, inputMode = "text" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mb-1 block text-xs font-semibold tracking-wide text-muted uppercase",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			value,
			inputMode,
			onChange: (event) => onChange(event.target.value),
			className: "h-12 w-full rounded-control border border-line bg-surface px-3 text-fg outline-none focus:border-primary"
		})]
	});
}
function Info({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
		className: "text-xs font-semibold tracking-wide text-muted uppercase",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
		className: "tabular-nums",
		children: value
	})] });
}
function Stars({ count }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "inline-flex gap-0.5",
		"aria-label": `${count} dari 3 bintang`,
		children: [
			0,
			1,
			2
		].map((index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, {
			className: "size-4 " + (index < count ? "fill-accent text-accent" : "text-line"),
			"aria-hidden": "true"
		}, index))
	});
}
function toForm(data) {
	return {
		nama: data.nama,
		panggilan: data.panggilan,
		umur: String(data.umur),
		kelas: data.kelas === "—" ? "" : data.kelas,
		sekolah: data.sekolah,
		favorit: String(data.favorit),
		hobi: data.hobi,
		cita: data.cita,
		skuad: data.skuad
	};
}
function parseInteger(raw) {
	const trimmed = raw.trim().replace("−", "-").replace(",", "");
	if (!/^-?\d+$/.test(trimmed)) return null;
	const value = Number(trimmed);
	if (!Number.isInteger(value) || value < -9999 || value > 9999) return null;
	return value;
}
var NAV = [
	{
		id: "markas",
		label: "Markas",
		icon: House
	},
	{
		id: "peta",
		label: "Bab",
		icon: BookOpen
	},
	{
		id: "latihan",
		label: "Latihan",
		icon: Calculator
	},
	{
		id: "biodata",
		label: "Kartu",
		icon: IdCard
	}
];
function AcademyApp() {
	const view = useAcademy((s) => s.view);
	const openView = useAcademy((s) => s.openView);
	(0, import_react.useEffect)(() => {
		useAcademy.persist.rehydrate();
	}, []);
	const current = view === "bab" ? "peta" : view;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "sky min-h-dvh text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex min-h-dvh w-full max-w-5xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "sticky top-0 hidden h-dvh w-56 shrink-0 flex-col gap-6 border-r border-line px-4 py-6 md:flex",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-lg leading-tight",
					children: "S-7 Starlink Hunter"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Akademi bilangan bulat"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Nav, {
					current,
					onPick: openView,
					vertical: true
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-w-0 flex-1 flex-col",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "flex items-center justify-between px-4 pt-4 md:px-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-sm tracking-wide md:hidden",
						children: "S-7 Starlink Hunter"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "hidden text-sm text-muted md:block",
						children: "Misi hari ini: pahami bilangan bulat"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
					className: "flex-1 px-4 pt-4 pb-28 md:px-8 md:pb-10",
					children: [
						view === "markas" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Markas, {}) : null,
						view === "peta" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PetaBab, {}) : null,
						view === "bab" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BabScreen, {}) : null,
						view === "latihan" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Latihan, {}) : null,
						view === "biodata" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BiodataScreen, {}) : null
					]
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
			className: "dock fixed inset-x-0 bottom-0 border-t border-line bg-surface md:hidden",
			"aria-label": "Menu utama",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Nav, {
				current,
				onPick: openView
			})
		})]
	});
}
function Nav({ current, onPick, vertical = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: vertical ? "flex flex-col gap-1" : "mx-auto grid max-w-lg grid-cols-4",
		children: NAV.map((item) => {
			const Icon = item.icon;
			const on = current === item.id;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => onPick(item.id),
				"aria-current": on ? "page" : void 0,
				className: "flex items-center gap-2 rounded-control text-sm font-semibold " + (vertical ? "h-12 justify-start px-3" : "h-16 flex-col justify-center px-2 text-xs") + (on ? " bg-raised text-primary" : " text-muted"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
					className: "size-5",
					"aria-hidden": "true"
				}), item.label]
			}, item.id);
		})
	});
}
var SplitComponent = AcademyApp;
//#endregion
export { SplitComponent as component };
