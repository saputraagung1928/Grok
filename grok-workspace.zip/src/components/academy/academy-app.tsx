import { useEffect } from "react";
import { BookOpen, Calculator, House, IdCard } from "lucide-react";
import { BabScreen, BiodataScreen, Latihan, Markas, PetaBab } from "@/components/academy/screens";
import { useAcademy, type View } from "@/lib/academy/store";

const NAV: { id: View; label: string; icon: typeof House }[] = [
  { id: "markas", label: "Markas", icon: House },
  { id: "peta", label: "Bab", icon: BookOpen },
  { id: "latihan", label: "Latihan", icon: Calculator },
  { id: "biodata", label: "Kartu", icon: IdCard },
];

export function AcademyApp() {
  const view = useAcademy((s) => s.view);
  const openView = useAcademy((s) => s.openView);

  useEffect(() => {
    void useAcademy.persist.rehydrate();
  }, []);

  const current = view === "bab" ? "peta" : view;

  return (
    <div className="sky min-h-dvh text-fg">
      <div className="mx-auto flex min-h-dvh w-full max-w-5xl">
        <aside className="sticky top-0 hidden h-dvh w-56 shrink-0 flex-col gap-6 border-r border-line px-4 py-6 md:flex">
          <div>
            <p className="font-display text-lg leading-tight">S-7 Starlink Hunter</p>
            <p className="text-sm text-muted">Akademi bilangan bulat</p>
          </div>
          <Nav current={current} onPick={openView} vertical />
        </aside>
        <div className="flex min-w-0 flex-1 flex-col">
          <header className="flex items-center justify-between px-4 pt-4 md:px-8">
            <p className="font-display text-sm tracking-wide md:hidden">S-7 Starlink Hunter</p>
            <p className="hidden text-sm text-muted md:block">Misi hari ini: pahami bilangan bulat</p>
          </header>
          <main className="flex-1 px-4 pt-4 pb-28 md:px-8 md:pb-10">
            {view === "markas" ? <Markas /> : null}
            {view === "peta" ? <PetaBab /> : null}
            {view === "bab" ? <BabScreen /> : null}
            {view === "latihan" ? <Latihan /> : null}
            {view === "biodata" ? <BiodataScreen /> : null}
          </main>
        </div>
      </div>
      <nav className="dock fixed inset-x-0 bottom-0 border-t border-line bg-surface md:hidden" aria-label="Menu utama">
        <Nav current={current} onPick={openView} />
      </nav>
    </div>
  );
}

function Nav({
  current,
  onPick,
  vertical = false,
}: {
  current: View;
  onPick: (view: View) => void;
  vertical?: boolean;
}) {
  return (
    <div className={vertical ? "flex flex-col gap-1" : "mx-auto grid max-w-lg grid-cols-4"}>
      {NAV.map((item) => {
        const Icon = item.icon;
        const on = current === item.id;
        return (
          <button
            key={item.id}
            type="button"
            onClick={() => onPick(item.id)}
            aria-current={on ? "page" : undefined}
            className={
              "flex items-center gap-2 rounded-control text-sm font-semibold " +
              (vertical ? "h-12 justify-start px-3" : "h-16 flex-col justify-center px-2 text-xs") +
              (on ? " bg-raised text-primary" : " text-muted")
            }
          >
            <Icon className="size-5" aria-hidden="true" />
            {item.label}
          </button>
        );
      })}
    </div>
  );
}
