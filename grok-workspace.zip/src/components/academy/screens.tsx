import { useEffect, useMemo, useState, type FormEvent } from "react";
import {
  ArrowRight,
  Check,
  Lock,
  RotateCcw,
  Satellite,
  Star,
} from "lucide-react";
import { CHAPTERS, chapterById, type Chapter } from "@/lib/academy/chapters";
import { makeProblem, type DrillLevel, type DrillOp, type Problem } from "@/lib/academy/drill";
import {
  callsign,
  clearedCount,
  isUnlocked,
  starTotal,
  useAcademy,
  type Biodata,
  type Skuad,
} from "@/lib/academy/store";
import { LessonToy } from "@/components/academy/toys";

export function Markas() {
  const biodata = useAcademy((s) => s.biodata);
  const best = useAcademy((s) => s.best);
  const openChapter = useAcademy((s) => s.openChapter);
  const openView = useAcademy((s) => s.openView);
  const next = CHAPTERS.find((chapter) => isUnlocked(chapter.id, best) && (best[chapter.id]?.stars ?? 0) < 1);
  const resume = next ?? CHAPTERS[CHAPTERS.length - 1];
  const name = biodata?.panggilan || biodata?.nama || "Kadet";
  const stars = starTotal(best);
  const done = clearedCount(best);

  return (
    <div className="rise grid gap-5 md:grid-cols-[1.15fr_0.85fr] md:items-center">
      <div>
        <p className="text-xs font-semibold tracking-widest text-primary uppercase">Sayap S-7 · Starlink</p>
        <h1 className="mt-2 font-display text-4xl text-fg">Halo, {name}.</h1>
        <p className="mt-2 max-w-md text-muted">
          Akademi Hunter untuk bilangan bulat. Selesaikan bab, kumpulkan bintang, lalu cetak kartu
          kadetmu di Mesin Biodata B.
        </p>
        <div className="mt-4 flex flex-wrap gap-2">
          <Stat label="Bab lulus" value={`${done}/6`} />
          <Stat label="Bintang" value={`${stars}/18`} />
          <Stat label="Kode" value={biodata ? callsign(biodata.nama, biodata.favorit) : "—"} />
        </div>
        <div className="mt-5 flex flex-wrap gap-2">
          <button
            type="button"
            onClick={() => openChapter(resume.id)}
            className="inline-flex h-12 items-center gap-2 rounded-control bg-accent px-4 font-semibold text-accent-fg"
          >
            {done === 0 ? "Mulai Bab 1" : `Lanjut ${resume.code}`}
            <ArrowRight className="size-4" aria-hidden="true" />
          </button>
          <button
            type="button"
            onClick={() => openView("biodata")}
            className="inline-flex h-12 items-center rounded-control bg-raised px-4 font-semibold text-fg"
          >
            Mesin Biodata B
          </button>
        </div>
      </div>
      <figure className="panel overflow-hidden">
        <img
          src="/academy/cadet.jpg"
          alt="Kadet muda berhelm teal berdiri di samping satelit kecil"
          className="aspect-square w-full object-cover"
        />
        <figcaption className="flex items-center gap-2 px-4 py-3 text-sm text-muted">
          <Satellite className="size-4 text-primary" aria-hidden="true" />
          Satelit kecil menemani setiap misi hitung.
        </figcaption>
      </figure>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="min-w-24 rounded-control bg-surface px-3 py-2">
      <p className="text-xs text-muted">{label}</p>
      <p className="font-display text-lg tabular-nums">{value}</p>
    </div>
  );
}

export function PetaBab() {
  const best = useAcademy((s) => s.best);
  const openChapter = useAcademy((s) => s.openChapter);
  return (
    <div className="rise">
      <h1 className="font-display text-3xl">Peta bab</h1>
      <p className="mt-1 text-muted">Bab berikutnya terbuka setelah kamu meraih minimal satu bintang.</p>
      <ol className="mt-4 space-y-2">
        {CHAPTERS.map((chapter) => {
          const open = isUnlocked(chapter.id, best);
          const record = best[chapter.id];
          return (
            <li key={chapter.id}>
              <button
                type="button"
                disabled={!open}
                onClick={() => openChapter(chapter.id)}
                className="panel flex w-full items-center gap-3 px-4 py-3 text-left disabled:opacity-50"
              >
                <span className="grid size-11 shrink-0 place-items-center rounded-control bg-raised font-display text-primary">
                  {open ? chapter.id : <Lock className="size-4" aria-hidden="true" />}
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block text-xs font-semibold tracking-wide text-muted uppercase">
                    {chapter.code}
                  </span>
                  <span className="block font-semibold">{chapter.title}</span>
                </span>
                <Stars count={record?.stars ?? 0} />
              </button>
            </li>
          );
        })}
      </ol>
    </div>
  );
}

export function BabScreen() {
  const chapterId = useAcademy((s) => s.chapterId);
  const phase = useAcademy((s) => s.phase);
  const setPhase = useAcademy((s) => s.setPhase);
  const openView = useAcademy((s) => s.openView);
  const chapter = chapterById(chapterId);

  return (
    <div className="rise">
      <button
        type="button"
        onClick={() => openView("peta")}
        className="text-sm font-semibold text-primary"
      >
        Kembali ke peta
      </button>
      <p className="mt-3 text-xs font-semibold tracking-widest text-primary uppercase">{chapter.code}</p>
      <h1 className="mt-1 font-display text-3xl">{chapter.title}</h1>
      <p className="mt-1 text-muted">{chapter.blurb}</p>
      <div className="mt-4 grid grid-cols-3 gap-1 rounded-control bg-surface p-1">
        {(
          [
            ["belajar", "Pelajaran"],
            ["soal", "Soal"],
            ["hasil", "Nilai"],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            type="button"
            onClick={() => setPhase(id)}
            className={
              "h-11 rounded-control text-sm font-semibold " +
              (phase === id ? "bg-primary text-primary-fg" : "text-muted")
            }
          >
            {label}
          </button>
        ))}
      </div>
      <div className="mt-4">
        {phase === "belajar" ? <Belajar chapter={chapter} /> : null}
        {phase === "soal" ? <Soal chapter={chapter} /> : null}
        {phase === "hasil" ? <Hasil chapter={chapter} /> : null}
      </div>
    </div>
  );
}

function Belajar({ chapter }: { chapter: Chapter }) {
  const setPhase = useAcademy((s) => s.setPhase);
  return (
    <div className="space-y-4">
      {chapter.lesson.map((paragraph) => (
        <p key={paragraph}>{paragraph}</p>
      ))}
      <div className="panel p-4">
        <p className="mb-3 text-xs font-semibold tracking-widest text-accent uppercase">Meja latihan</p>
        <LessonToy toy={chapter.toy} />
      </div>
      <button
        type="button"
        onClick={() => setPhase("soal")}
        className="inline-flex h-12 items-center gap-2 rounded-control bg-accent px-4 font-semibold text-accent-fg"
      >
        Kerjakan 5 soal
        <ArrowRight className="size-4" aria-hidden="true" />
      </button>
    </div>
  );
}

function Soal({ chapter }: { chapter: Chapter }) {
  const qIndex = useAcademy((s) => s.qIndex);
  const picked = useAcademy((s) => s.picked);
  const pick = useAcademy((s) => s.pick);
  const nextQuestion = useAcademy((s) => s.nextQuestion);
  const question = chapter.questions[qIndex];
  if (!question) return null;
  const revealed = picked !== null;

  return (
    <div className="panel p-4">
      <p className="text-xs font-semibold tracking-wide text-muted uppercase">
        Soal {qIndex + 1} dari {chapter.questions.length}
      </p>
      <h2 className="mt-2 font-display text-2xl">{question.prompt}</h2>
      <div className="mt-4 grid gap-2">
        {question.choices.map((choice, index) => {
          const selected = picked === index;
          const correct = index === question.answer;
          let tone = "bg-raised text-fg";
          if (revealed && correct) tone = "bg-primary text-primary-fg";
          else if (revealed && selected) tone = "bg-accent text-accent-fg";
          return (
            <button
              key={choice}
              type="button"
              disabled={revealed}
              onClick={() => pick(index, correct)}
              className={`min-h-12 rounded-control px-4 py-3 text-left font-semibold ${tone}`}
            >
              {choice}
            </button>
          );
        })}
      </div>
      {revealed ? (
        <div className="mt-4">
          <p className="text-sm font-semibold">{picked === question.answer ? "Tepat." : "Belum tepat."}</p>
          <p className="mt-1 text-sm text-muted">{question.why}</p>
          <button
            type="button"
            onClick={() => nextQuestion(chapter.questions.length)}
            className="mt-3 inline-flex h-12 items-center gap-2 rounded-control bg-primary px-4 font-semibold text-primary-fg"
          >
            {qIndex + 1 === chapter.questions.length ? "Lihat nilai" : "Lanjut"}
            <ArrowRight className="size-4" aria-hidden="true" />
          </button>
        </div>
      ) : null}
    </div>
  );
}

function Hasil({ chapter }: { chapter: Chapter }) {
  const attempt = useAcademy((s) => s.attempt);
  const best = useAcademy((s) => s.best);
  const restartQuiz = useAcademy((s) => s.restartQuiz);
  const openChapter = useAcademy((s) => s.openChapter);
  const record = best[chapter.id];
  const passed = (record?.stars ?? 0) >= 1;
  const next = CHAPTERS.find((item) => item.id === chapter.id + 1);

  return (
    <div className="panel p-4">
      {attempt ? (
        <>
          <p className="text-xs font-semibold tracking-widest text-muted uppercase">Hasil kali ini</p>
          <p className="mt-2 font-display text-4xl tabular-nums">
            {attempt.correct}
            <span className="text-xl text-muted">/{chapter.questions.length}</span>
          </p>
          <div className="mt-2">
            <Stars count={attempt.stars} />
          </div>
        </>
      ) : (
        <p>Kerjakan soal dulu supaya nilainya muncul di sini.</p>
      )}
      <p className="mt-3 text-sm text-muted">
        Rekor bab ini: {record ? `${record.correct}/${chapter.questions.length}` : "belum ada"}.{" "}
        {passed
          ? "Bab ini lulus. Satu bintang sudah cukup untuk membuka bab berikut."
          : "Butuh minimal 3 benar dari 5 soal supaya bab berikut terbuka."}
      </p>
      <div className="mt-4 flex flex-wrap gap-2">
        <button
          type="button"
          onClick={restartQuiz}
          className="inline-flex h-12 items-center gap-2 rounded-control bg-raised px-4 font-semibold"
        >
          <RotateCcw className="size-4" aria-hidden="true" />
          Ulangi soal
        </button>
        {next && passed ? (
          <button
            type="button"
            onClick={() => openChapter(next.id)}
            className="inline-flex h-12 items-center gap-2 rounded-control bg-accent px-4 font-semibold text-accent-fg"
          >
            {next.code}
            <ArrowRight className="size-4" aria-hidden="true" />
          </button>
        ) : null}
      </div>
    </div>
  );
}

const OPS: { id: DrillOp; label: string }[] = [
  { id: "tambah", label: "Tambah" },
  { id: "kurang", label: "Kurang" },
  { id: "kali", label: "Kali" },
  { id: "bagi", label: "Bagi" },
];

export function Latihan() {
  const [level, setLevel] = useState<DrillLevel>("mudah");
  const [op, setOp] = useState<DrillOp>("tambah");
  const [problem, setProblem] = useState<Problem | null>(null);
  const [picked, setPicked] = useState<number | null>(null);
  const [streak, setStreak] = useState(0);
  const [seen, setSeen] = useState(0);
  const [right, setRight] = useState(0);

  function fresh(nextLevel = level, nextOp = op) {
    setProblem(makeProblem(nextLevel, nextOp));
    setPicked(null);
    setSeen((count) => count + 1);
  }

  function choose(value: number) {
    if (!problem || picked !== null) return;
    setPicked(value);
    if (value === problem.answer) {
      setRight((count) => count + 1);
      setStreak((count) => count + 1);
    } else {
      setStreak(0);
    }
  }

  return (
    <div className="rise">
      <h1 className="font-display text-3xl">Mesin latihan</h1>
      <p className="mt-1 text-muted">Soal baru tiap kali. Tidak ada waktu, jadi hitung dengan tenang.</p>
      <div className="mt-4 flex flex-wrap gap-2">
        {OPS.map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => {
              setOp(item.id);
              if (problem) fresh(level, item.id);
            }}
            className={
              "h-11 rounded-control px-3 text-sm font-semibold " +
              (op === item.id ? "bg-primary text-primary-fg" : "bg-surface text-fg")
            }
          >
            {item.label}
          </button>
        ))}
      </div>
      <div className="mt-2 flex gap-2">
        {(["mudah", "sedang"] as const).map((item) => (
          <button
            key={item}
            type="button"
            onClick={() => {
              setLevel(item);
              if (problem) fresh(item, op);
            }}
            className={
              "h-11 rounded-control px-3 text-sm font-semibold capitalize " +
              (level === item ? "bg-accent text-accent-fg" : "bg-surface text-fg")
            }
          >
            {item}
          </button>
        ))}
      </div>
      <div className="mt-4 flex gap-4 text-sm text-muted">
        <span className="tabular-nums">Benar {right}</span>
        <span className="tabular-nums">Soal {seen}</span>
        <span className="tabular-nums">Runtut {streak}</span>
      </div>
      {problem ? (
        <div className="panel mt-4 p-4">
          <p className="font-display text-3xl tabular-nums">{problem.prompt}</p>
          <div className="mt-4 grid grid-cols-2 gap-2">
            {problem.choices.map((choice) => {
              const revealed = picked !== null;
              const selected = picked === choice;
              const correct = choice === problem.answer;
              let tone = "bg-raised text-fg";
              if (revealed && correct) tone = "bg-primary text-primary-fg";
              else if (revealed && selected) tone = "bg-accent text-accent-fg";
              return (
                <button
                  key={choice}
                  type="button"
                  disabled={revealed}
                  onClick={() => choose(choice)}
                  className={`h-14 rounded-control font-display text-xl tabular-nums ${tone}`}
                >
                  {choice}
                </button>
              );
            })}
          </div>
          {picked !== null ? (
            <button
              type="button"
              onClick={() => fresh()}
              className="mt-4 inline-flex h-12 items-center gap-2 rounded-control bg-primary px-4 font-semibold text-primary-fg"
            >
              Soal berikut
              <ArrowRight className="size-4" aria-hidden="true" />
            </button>
          ) : null}
        </div>
      ) : (
        <button
          type="button"
          onClick={() => fresh()}
          className="mt-5 inline-flex h-12 items-center gap-2 rounded-control bg-accent px-4 font-semibold text-accent-fg"
        >
          Mulai soal
          <ArrowRight className="size-4" aria-hidden="true" />
        </button>
      )}
    </div>
  );
}

const EMPTY_FORM = {
  nama: "",
  panggilan: "",
  umur: "11",
  kelas: "",
  sekolah: "",
  favorit: "",
  hobi: "",
  cita: "",
  skuad: "ombak" as Skuad,
};

export function BiodataScreen() {
  const saved = useAcademy((s) => s.biodata);
  const saveBiodata = useAcademy((s) => s.saveBiodata);
  const clearBiodata = useAcademy((s) => s.clearBiodata);
  const [form, setForm] = useState(() => (saved ? toForm(saved) : EMPTY_FORM));
  const [error, setError] = useState("");
  const [confirmClear, setConfirmClear] = useState(false);
  const [printed, setPrinted] = useState<Biodata | null>(saved);

  useEffect(() => {
    const apply = () => {
      const data = useAcademy.getState().biodata;
      if (!data) return;
      setForm(toForm(data));
      setPrinted(data);
    };
    const unsub = useAcademy.persist.onFinishHydration(apply);
    if (useAcademy.persist.hasHydrated()) apply();
    return unsub;
  }, []);

  function update(key: keyof typeof form, value: string) {
    setForm((current) => ({ ...current, [key]: value }));
  }

  function onSubmit(event: FormEvent) {
    event.preventDefault();
    const nama = form.nama.trim();
    const umur = Number(form.umur);
    const favorit = parseInteger(form.favorit);
    if (nama.length < 2) {
      setError("Isi nama, minimal 2 huruf.");
      return;
    }
    if (!Number.isInteger(umur) || umur < 5 || umur > 99) {
      setError("Umur diisi angka utuh, dari 5 sampai 99.");
      return;
    }
    if (favorit === null) {
      setError("Bilangan favorit harus bilangan bulat, misalnya 7 atau −4.");
      return;
    }
    if (form.hobi.trim().length < 2 || form.cita.trim().length < 2) {
      setError("Isi hobi dan cita-cita.");
      return;
    }
    const next: Biodata = {
      nama,
      panggilan: form.panggilan.trim() || nama.split(" ")[0] || nama,
      umur,
      kelas: form.kelas.trim() || "—",
      sekolah: form.sekolah.trim(),
      favorit,
      hobi: form.hobi.trim(),
      cita: form.cita.trim(),
      skuad: form.skuad,
    };
    saveBiodata(next);
    setPrinted(next);
    setError("");
    setConfirmClear(false);
  }

  const card = printed ?? saved;
  const previewSign = useMemo(
    () => (card ? callsign(card.nama, card.favorit) : ""),
    [card],
  );

  return (
    <div className="rise grid gap-5 lg:grid-cols-2">
      <div>
        <h1 className="font-display text-3xl">Mesin Biodata B</h1>
        <p className="mt-1 text-muted">
          Isi data kamu sendiri. Kartu hanya tersimpan di perangkat ini, bukan data orang lain.
        </p>
        <form onSubmit={onSubmit} className="mt-4 space-y-3">
          <Field label="Nama" value={form.nama} onChange={(value) => update("nama", value)} />
          <Field
            label="Nama panggilan"
            value={form.panggilan}
            onChange={(value) => update("panggilan", value)}
          />
          <div className="grid grid-cols-2 gap-3">
            <Field label="Umur" value={form.umur} onChange={(value) => update("umur", value)} inputMode="numeric" />
            <Field label="Kelas" value={form.kelas} onChange={(value) => update("kelas", value)} />
          </div>
          <Field label="Sekolah" value={form.sekolah} onChange={(value) => update("sekolah", value)} />
          <Field
            label="Bilangan bulat favorit"
            value={form.favorit}
            onChange={(value) => update("favorit", value)}
            inputMode="text"
          />
          <Field label="Hobi" value={form.hobi} onChange={(value) => update("hobi", value)} />
          <Field label="Cita-cita" value={form.cita} onChange={(value) => update("cita", value)} />
          <fieldset>
            <legend className="mb-1 text-xs font-semibold tracking-wide text-muted uppercase">Skuad</legend>
            <div className="flex gap-2">
              {(
                [
                  ["ombak", "Ombak"],
                  ["surya", "Surya"],
                ] as const
              ).map(([id, label]) => (
                <button
                  key={id}
                  type="button"
                  onClick={() => update("skuad", id)}
                  className={
                    "h-11 flex-1 rounded-control font-semibold " +
                    (form.skuad === id
                      ? id === "surya"
                        ? "bg-accent text-accent-fg"
                        : "bg-primary text-primary-fg"
                      : "bg-surface text-fg")
                  }
                >
                  {label}
                </button>
              ))}
            </div>
          </fieldset>
          {error ? <p className="text-sm font-semibold text-accent">{error}</p> : null}
          <button
            type="submit"
            className="inline-flex h-12 items-center gap-2 rounded-control bg-accent px-4 font-semibold text-accent-fg"
          >
            <Check className="size-4" aria-hidden="true" />
            Cetak kartu
          </button>
        </form>
      </div>
      <div>
        {card ? (
          <article className={"panel overflow-hidden " + (card.skuad === "surya" ? "skuad-surya" : "skuad-ombak")}>
            <div className="flex items-center justify-between bg-raised px-4 py-3">
              <p className="text-xs font-semibold tracking-widest uppercase">Kartu kadet · Seri B</p>
              <Satellite className="size-4 text-primary" aria-hidden="true" />
            </div>
            <div className="space-y-3 p-4">
              <p className="font-display text-3xl">{card.panggilan}</p>
              <p className="text-muted">{card.nama}</p>
              <dl className="grid grid-cols-2 gap-3 text-sm">
                <Info label="Umur" value={`${card.umur} tahun`} />
                <Info label="Kelas" value={card.kelas} />
                <Info label="Sekolah" value={card.sekolah || "—"} />
                <Info label="Skuad" value={card.skuad === "surya" ? "Surya" : "Ombak"} />
                <Info label="Bilangan favorit" value={String(card.favorit)} />
                <Info label="Kode" value={previewSign} />
              </dl>
              <p>
                <span className="text-xs font-semibold tracking-wide text-muted uppercase">Hobi</span>
                <span className="mt-1 block">{card.hobi}</span>
              </p>
              <p>
                <span className="text-xs font-semibold tracking-wide text-muted uppercase">Cita-cita</span>
                <span className="mt-1 block">{card.cita}</span>
              </p>
            </div>
          </article>
        ) : (
          <div className="panel grid min-h-64 place-items-center p-6 text-center">
            <div>
              <Satellite className="mx-auto size-8 text-primary" aria-hidden="true" />
              <p className="mt-3 font-semibold">Mesin masih kosong</p>
              <p className="mt-1 text-sm text-muted">Cetak kartu setelah formulir terisi.</p>
            </div>
          </div>
        )}
        {saved ? (
          <button
            type="button"
            onClick={() => {
              if (!confirmClear) {
                setConfirmClear(true);
                return;
              }
              clearBiodata();
              setPrinted(null);
              setForm(EMPTY_FORM);
              setConfirmClear(false);
            }}
            className="mt-3 h-11 text-sm font-semibold text-muted"
          >
            {confirmClear ? "Yakin hapus kartu ini?" : "Hapus kartu di perangkat ini"}
          </button>
        ) : null}
      </div>
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  inputMode = "text",
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  inputMode?: "text" | "numeric";
}) {
  return (
    <label className="block">
      <span className="mb-1 block text-xs font-semibold tracking-wide text-muted uppercase">{label}</span>
      <input
        value={value}
        inputMode={inputMode}
        onChange={(event) => onChange(event.target.value)}
        className="h-12 w-full rounded-control border border-line bg-surface px-3 text-fg outline-none focus:border-primary"
      />
    </label>
  );
}

function Info({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="text-xs font-semibold tracking-wide text-muted uppercase">{label}</dt>
      <dd className="tabular-nums">{value}</dd>
    </div>
  );
}

function Stars({ count }: { count: number }) {
  return (
    <span className="inline-flex gap-0.5" aria-label={`${count} dari 3 bintang`}>
      {[0, 1, 2].map((index) => (
        <Star
          key={index}
          className={"size-4 " + (index < count ? "fill-accent text-accent" : "text-line")}
          aria-hidden="true"
        />
      ))}
    </span>
  );
}

function toForm(data: Biodata) {
  return {
    nama: data.nama,
    panggilan: data.panggilan,
    umur: String(data.umur),
    kelas: data.kelas === "—" ? "" : data.kelas,
    sekolah: data.sekolah,
    favorit: String(data.favorit),
    hobi: data.hobi,
    cita: data.cita,
    skuad: data.skuad,
  };
}

function parseInteger(raw: string) {
  const trimmed = raw.trim().replace("−", "-").replace(",", "");
  if (!/^-?\d+$/.test(trimmed)) return null;
  const value = Number(trimmed);
  if (!Number.isInteger(value) || value < -9999 || value > 9999) return null;
  return value;
}
