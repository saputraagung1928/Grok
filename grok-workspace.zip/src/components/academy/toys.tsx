import { useState } from "react";
import type { Toy } from "@/lib/academy/chapters";

const LINE = [-6, -5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5, 6];

function describe(n: number) {
  if (n > 0) return `${n} positif. Letaknya ${n} langkah di kanan nol.`;
  if (n < 0) return `${n} negatif. Letaknya ${Math.abs(n)} langkah di kiri nol.`;
  return "Nol tepat di tengah. Bukan positif, bukan negatif.";
}

export function LessonToy({ toy }: { toy: Toy }) {
  if (toy === "kenal") return <Kenal />;
  if (toy === "garis") return <Garis />;
  if (toy === "hitung") return <Hitung />;
  if (toy === "tanda") return <Tanda />;
  return <Mutlak />;
}

function Kenal() {
  const cards = [
    { n: "−3", label: "Negatif", note: "Di kiri nol" },
    { n: "0", label: "Nol", note: "Titik tengah" },
    { n: "+5", label: "Positif", note: "Di kanan nol" },
  ];
  return (
    <div className="grid grid-cols-3 gap-2">
      {cards.map((card) => (
        <div key={card.n} className="rounded-control bg-raised px-2 py-3 text-center">
          <p className="font-display text-2xl tabular-nums text-accent">{card.n}</p>
          <p className="mt-1 text-sm font-semibold">{card.label}</p>
          <p className="text-xs text-muted">{card.note}</p>
        </div>
      ))}
    </div>
  );
}

function Garis() {
  const [picked, setPicked] = useState(0);
  return (
    <div>
      <div className="flex flex-wrap justify-center gap-1">
        {LINE.map((n) => {
          const on = n === picked;
          return (
            <button
              key={n}
              type="button"
              onClick={() => setPicked(n)}
              className={
                "size-11 rounded-control text-sm font-semibold tabular-nums " +
                (on ? "bg-primary text-primary-fg" : "bg-raised text-fg")
              }
              aria-pressed={on}
            >
              {n}
            </button>
          );
        })}
      </div>
      <p className="mt-3 text-sm text-muted">{describe(picked)}</p>
    </div>
  );
}

function Hitung() {
  const [left, setLeft] = useState(4);
  const [right, setRight] = useState(-2);
  const [minus, setMinus] = useState(false);
  const result = minus ? left - right : left + right;
  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-end gap-3">
        <Stepper label="Angka pertama" value={left} onChange={setLeft} />
        <div className="flex gap-1 pb-1">
          <button
            type="button"
            onClick={() => setMinus(false)}
            className={
              "h-11 rounded-control px-3 font-semibold " +
              (!minus ? "bg-primary text-primary-fg" : "bg-raised text-fg")
            }
          >
            tambah
          </button>
          <button
            type="button"
            onClick={() => setMinus(true)}
            className={
              "h-11 rounded-control px-3 font-semibold " +
              (minus ? "bg-primary text-primary-fg" : "bg-raised text-fg")
            }
          >
            kurang
          </button>
        </div>
        <Stepper label="Angka kedua" value={right} onChange={setRight} />
      </div>
      <p className="font-display text-2xl tabular-nums">
        {left} {minus ? "−" : "+"} ({right}) = <span className="text-accent">{result}</span>
      </p>
    </div>
  );
}

function Tanda() {
  const [leftNeg, setLeftNeg] = useState(true);
  const [rightNeg, setRightNeg] = useState(false);
  const productNeg = leftNeg !== rightNeg;
  return (
    <div className="space-y-3">
      <div className="flex flex-wrap gap-2">
        <SignToggle label="Angka A" negative={leftNeg} onChange={setLeftNeg} />
        <SignToggle label="Angka B" negative={rightNeg} onChange={setRightNeg} />
      </div>
      <p className="text-sm text-muted">
        {productNeg
          ? "Tandanya beda, jadi hasil kali negatif."
          : "Tandanya sama, jadi hasil kali positif."}
      </p>
      <p className="font-display text-xl">
        Hasil:{" "}
        <span className="text-accent">{productNeg ? "negatif" : "positif"}</span>
      </p>
    </div>
  );
}

function Mutlak() {
  const [n, setN] = useState(-4);
  return (
    <div>
      <Stepper label="Pilih angka" value={n} onChange={setN} min={-9} max={9} />
      <p className="mt-3 font-display text-2xl tabular-nums">
        |{n}| = <span className="text-accent">{Math.abs(n)}</span>
      </p>
      <div className="mt-3 h-3 overflow-hidden rounded-full bg-raised">
        <div
          className="h-full rounded-full bg-primary"
          style={{ width: `${(Math.abs(n) / 9) * 100}%` }}
        />
      </div>
      <p className="mt-2 text-sm text-muted">Batang ini menunjukkan jarak ke nol, tanpa tanda.</p>
    </div>
  );
}

function Stepper({
  label,
  value,
  onChange,
  min = -8,
  max = 8,
}: {
  label: string;
  value: number;
  onChange: (next: number) => void;
  min?: number;
  max?: number;
}) {
  return (
    <div>
      <p className="mb-1 text-xs font-semibold tracking-wide text-muted uppercase">{label}</p>
      <div className="flex items-center gap-2">
        <button
          type="button"
          className="size-11 rounded-control bg-raised text-lg font-semibold"
          onClick={() => onChange(Math.max(min, value - 1))}
          aria-label={`Kurangi ${label}`}
        >
          −
        </button>
        <span className="w-10 text-center font-display text-2xl tabular-nums">{value}</span>
        <button
          type="button"
          className="size-11 rounded-control bg-raised text-lg font-semibold"
          onClick={() => onChange(Math.min(max, value + 1))}
          aria-label={`Tambah ${label}`}
        >
          +
        </button>
      </div>
    </div>
  );
}

function SignToggle({
  label,
  negative,
  onChange,
}: {
  label: string;
  negative: boolean;
  onChange: (next: boolean) => void;
}) {
  return (
    <div className="rounded-control bg-raised px-3 py-2">
      <p className="text-xs font-semibold tracking-wide text-muted uppercase">{label}</p>
      <div className="mt-1 flex gap-1">
        <button
          type="button"
          onClick={() => onChange(false)}
          className={
            "h-11 rounded-control px-3 font-semibold " +
            (!negative ? "bg-primary text-primary-fg" : "text-fg")
          }
        >
          positif
        </button>
        <button
          type="button"
          onClick={() => onChange(true)}
          className={
            "h-11 rounded-control px-3 font-semibold " +
            (negative ? "bg-accent text-accent-fg" : "text-fg")
          }
        >
          negatif
        </button>
      </div>
    </div>
  );
}
