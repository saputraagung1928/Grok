export type Question = {
  prompt: string;
  choices: [string, string, string, string];
  answer: 0 | 1 | 2 | 3;
  why: string;
};

export type Toy = "kenal" | "garis" | "hitung" | "tanda" | "mutlak";

export type Chapter = {
  id: number;
  code: string;
  title: string;
  blurb: string;
  toy: Toy;
  lesson: string[];
  questions: Question[];
};

export const CHAPTERS: Chapter[] = [
  {
    id: 1,
    code: "Bab 01",
    title: "Kenalan dengan bilangan bulat",
    blurb: "Positif, negatif, dan nol — tiga penghuni garis angka.",
    toy: "kenal",
    lesson: [
      "Bilangan bulat adalah angka utuh: … −3, −2, −1, 0, 1, 2, 3 … Tidak ada koma.",
      "Angka lebih dari nol disebut positif. Angka kurang dari nol disebut negatif. Nol bukan positif dan bukan negatif, tapi tetap bilangan bulat.",
      "Lawan dari 5 adalah −5. Lawan dari −5 adalah 5. Keduanya sama jauh dari nol.",
    ],
    questions: [
      {
        prompt: "Mana yang bukan bilangan bulat?",
        choices: ["4", "−9", "0", "3,5"],
        answer: 3,
        why: "3,5 punya koma, jadi pecahan. Bilangan bulat selalu utuh.",
      },
      {
        prompt: "Lawan dari −6 adalah …",
        choices: ["−6", "0", "6", "12"],
        answer: 2,
        why: "Lawan sebuah bilangan adalah angka yang sama jauhnya di sisi lain nol.",
      },
      {
        prompt: "Urutan dari yang terkecil, mana yang benar?",
        choices: ["2, 0, −1, −3", "−3, −1, 0, 2", "0, −3, −1, 2", "−1, −3, 0, 2"],
        answer: 1,
        why: "Di garis bilangan, yang lebih kiri selalu lebih kecil.",
      },
      {
        prompt: "Bilangan bulat negatif berada di … nol.",
        choices: ["kanan", "kiri", "atas", "dalam"],
        answer: 1,
        why: "Negatif di kiri nol, positif di kanan nol.",
      },
      {
        prompt: "Nol termasuk …",
        choices: [
          "bilangan positif",
          "bilangan negatif",
          "bilangan bulat",
          "pecahan",
        ],
        answer: 2,
        why: "Nol adalah bilangan bulat. Ia bukan positif dan bukan negatif.",
      },
    ],
  },
  {
    id: 2,
    code: "Bab 02",
    title: "Garis bilangan",
    blurb: "Geser ke kanan berarti bertambah. Geser ke kiri berarti berkurang.",
    toy: "garis",
    lesson: [
      "Garis bilangan adalah peta semua bilangan bulat. Nol di tengah.",
      "Melangkah ke kanan menambah. Melangkah ke kiri mengurangi.",
      "Jarak dua angka adalah selisihnya, selalu dihitung positif. Dari −2 ke 3 ada 5 langkah.",
    ],
    questions: [
      {
        prompt: "Angka di sebelah kanan selalu lebih …",
        choices: ["kecil", "besar", "genap", "negatif"],
        answer: 1,
        why: "Makin ke kanan, nilainya makin besar.",
      },
      {
        prompt: "Jarak dari −2 ke 3 adalah …",
        choices: ["1", "5", "6", "−5"],
        answer: 1,
        why: "Dari −2 ke 0 ada 2 langkah, lalu ke 3 ada 3 langkah. Total 5.",
      },
      {
        prompt: "Empat langkah ke kiri dari 1 mendarat di …",
        choices: ["5", "−3", "−4", "3"],
        answer: 1,
        why: "1 − 4 = −3.",
      },
      {
        prompt: "Ada berapa bilangan bulat di antara −1 dan 2?",
        choices: ["1", "2", "3", "4"],
        answer: 1,
        why: "Yang di tengah, tidak termasuk ujungnya, hanya 0 dan 1.",
      },
      {
        prompt: "Mana yang lebih dekat ke nol?",
        choices: ["−8", "6", "keduanya sama", "tidak bisa dibanding"],
        answer: 1,
        why: "Jarak −8 adalah 8. Jarak 6 adalah 6. Enam lebih dekat.",
      },
    ],
  },
  {
    id: 3,
    code: "Bab 03",
    title: "Tambah dan kurang",
    blurb: "Menggabungkan langkah kanan dan kiri.",
    toy: "hitung",
    lesson: [
      "Menambah bilangan positif sama dengan melangkah ke kanan. Menambah bilangan negatif sama dengan melangkah ke kiri.",
      "Mengurangi sama dengan berjalan ke arah sebaliknya. 4 − (−6) berarti 4 ditambah 6, hasilnya 10.",
      "Urutan hitung dari kiri ke kanan jika hanya ada tambah dan kurang.",
    ],
    questions: [
      {
        prompt: "7 + (−4) = …",
        choices: ["11", "3", "−3", "−11"],
        answer: 1,
        why: "Mulai di 7, lalu 4 langkah ke kiri. Mendarat di 3.",
      },
      {
        prompt: "−5 + (−3) = …",
        choices: ["−8", "−2", "8", "2"],
        answer: 0,
        why: "Dua langkah ke kiri digabung: −5 dan −3 menjadi −8.",
      },
      {
        prompt: "4 − (−6) = …",
        choices: ["−2", "2", "10", "−10"],
        answer: 2,
        why: "Mengurangi negatif sama dengan menambah. 4 + 6 = 10.",
      },
      {
        prompt: "−9 − 2 = …",
        choices: ["−7", "−11", "11", "7"],
        answer: 1,
        why: "Dari −9, langkah 2 lagi ke kiri. Hasilnya −11.",
      },
      {
        prompt: "−3 + 8 + (−1) = …",
        choices: ["4", "6", "−12", "10"],
        answer: 0,
        why: "−3 + 8 = 5, lalu 5 + (−1) = 4.",
      },
    ],
  },
  {
    id: 4,
    code: "Bab 04",
    title: "Kali dan bagi",
    blurb: "Aturan tanda: sama-sama hasilnya positif, beda hasilnya negatif.",
    toy: "tanda",
    lesson: [
      "Positif kali positif = positif. Negatif kali negatif = positif. Tanda beda = negatif.",
      "Pembagian memakai aturan tanda yang sama. Nol kali apa pun tetap nol.",
      "Tidak bisa membagi dengan nol. Di latihan ini pembagi selalu bukan nol.",
    ],
    questions: [
      {
        prompt: "(−4) × 5 = …",
        choices: ["20", "−20", "9", "−1"],
        answer: 1,
        why: "Tanda beda, jadi negatif. 4 × 5 = 20, hasilnya −20.",
      },
      {
        prompt: "(−3) × (−6) = …",
        choices: ["−18", "−9", "18", "9"],
        answer: 2,
        why: "Negatif kali negatif menghasilkan positif. 3 × 6 = 18.",
      },
      {
        prompt: "12 ÷ (−3) = …",
        choices: ["4", "−4", "9", "−9"],
        answer: 1,
        why: "12 ÷ 3 = 4, tandanya beda, jadi −4.",
      },
      {
        prompt: "(−24) ÷ (−8) = …",
        choices: ["−3", "3", "−16", "32"],
        answer: 1,
        why: "Tanda sama-sama negatif, hasilnya positif. 24 ÷ 8 = 3.",
      },
      {
        prompt: "0 × (−15) = …",
        choices: ["−15", "15", "0", "1"],
        answer: 2,
        why: "Nol kali bilangan apa pun tetap nol.",
      },
    ],
  },
  {
    id: 5,
    code: "Bab 05",
    title: "Bandingkan dan nilai mutlak",
    blurb: "Mana lebih besar, dan seberapa jauh dari nol.",
    toy: "mutlak",
    lesson: [
      "Untuk membandingkan, lihat posisinya di garis. Yang lebih kanan lebih besar. −2 lebih besar dari −9.",
      "Nilai mutlak |n| adalah jarak n ke nol. Selalu nol atau positif. |−9| = 9 dan |9| = 9.",
      "Dua angka bisa sama jauh dari nol tapi beda tanda.",
    ],
    questions: [
      {
        prompt: "Pernyataan yang benar adalah …",
        choices: ["−7 > −2", "−7 < −2", "−7 = −2", "−2 < −7"],
        answer: 1,
        why: "−7 lebih kiri, jadi lebih kecil daripada −2.",
      },
      {
        prompt: "Nilai mutlak |−9| = …",
        choices: ["−9", "0", "9", "18"],
        answer: 2,
        why: "Jarak −9 ke nol adalah 9.",
      },
      {
        prompt: "|−3| dibanding |3| …",
        choices: ["lebih kecil", "lebih besar", "sama dengan", "tidak ada"],
        answer: 2,
        why: "Keduanya berjarak 3 dari nol.",
      },
      {
        prompt: "Yang paling besar di antara 4, −1, dan −6 adalah …",
        choices: ["−6", "−1", "4", "semua sama"],
        answer: 2,
        why: "4 satu-satunya yang positif, jadi paling kanan.",
      },
      {
        prompt: "−10 … −4",
        choices: ["lebih besar dari", "sama dengan", "lebih kecil dari", "bukan bilangan bulat"],
        answer: 2,
        why: "−10 lebih kiri dari −4, jadi lebih kecil.",
      },
    ],
  },
  {
    id: 6,
    code: "Bab 06",
    title: "Ujian Hunter",
    blurb: "Gabungan semua bab. Lulus ini, kamu kadet hitung Sayap S-7.",
    toy: "hitung",
    lesson: [
      "Ujian ini mencampur tambah, kurang, kali, bagi, dan nilai mutlak.",
      "Kerjakan tanda kurung dan kali-bagi lebih dulu, baru tambah-kurang.",
      "Kalau ragu, gambar garis bilangan kecil di kertas. Tiga bintang artinya semua benar.",
    ],
    questions: [
      {
        prompt: "−6 + 9 − (−2) = …",
        choices: ["1", "5", "−17", "17"],
        answer: 1,
        why: "−6 + 9 = 3, lalu 3 − (−2) = 3 + 2 = 5.",
      },
      {
        prompt: "(−5) × (−2) + (−4) = …",
        choices: ["6", "14", "−6", "−14"],
        answer: 0,
        why: "(−5) × (−2) = 10, lalu 10 + (−4) = 6.",
      },
      {
        prompt: "18 ÷ (−2) − 3 = …",
        choices: ["−6", "−12", "12", "6"],
        answer: 1,
        why: "18 ÷ (−2) = −9, lalu −9 − 3 = −12.",
      },
      {
        prompt: "Nilai mutlak dari −8 + 3 adalah …",
        choices: ["−5", "5", "11", "−11"],
        answer: 1,
        why: "−8 + 3 = −5, dan |−5| = 5.",
      },
      {
        prompt: "Hasil mana yang paling besar?",
        choices: ["−3 × 4", "−20 ÷ 5", "2 + (−7)", "−1 − (−6)"],
        answer: 3,
        why: "Hasilnya berturut-turut −12, −4, −5, dan 5. Lima yang terbesar.",
      },
    ],
  },
];

export function chapterById(id: number) {
  return CHAPTERS.find((chapter) => chapter.id === id) ?? CHAPTERS[0];
}
