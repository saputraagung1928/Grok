export type DrillOp = "tambah" | "kurang" | "kali" | "bagi";
export type DrillLevel = "mudah" | "sedang";

export type Problem = {
  prompt: string;
  answer: number;
  choices: number[];
};

function rand(min: number, max: number) {
  return min + Math.floor(Math.random() * (max - min + 1));
}

function shuffle(values: number[]) {
  const list = [...values];
  for (let index = list.length - 1; index > 0; index -= 1) {
    const swap = Math.floor(Math.random() * (index + 1));
    const current = list[index] ?? 0;
    list[index] = list[swap] ?? 0;
    list[swap] = current;
  }
  return list;
}

function choicesFor(answer: number) {
  const bag = new Set<number>([answer]);
  const offsets = [1, -1, 2, -2, 3, -3, 4, -4, 5, -5, 10, -10];
  for (const offset of offsets) {
    if (bag.size >= 4) break;
    bag.add(answer + offset);
  }
  return shuffle([...bag]);
}

export function makeProblem(level: DrillLevel, op: DrillOp): Problem {
  const span = level === "mudah" ? 8 : 16;
  if (op === "bagi") {
    const divisorMag = rand(1, level === "mudah" ? 6 : 9);
    const divisor = Math.random() < 0.5 ? -divisorMag : divisorMag;
    const quotient = rand(-span, span) || 1;
    const dividend = quotient * divisor;
    return {
      prompt: `${dividend} ÷ (${divisor})`,
      answer: quotient,
      choices: choicesFor(quotient),
    };
  }

  const left = rand(-span, span);
  const right = rand(-span, span);
  if (op === "kurang") {
    return {
      prompt: `${left} − (${right})`,
      answer: left - right,
      choices: choicesFor(left - right),
    };
  }
  if (op === "kali") {
    const a = rand(-Math.min(span, 9), Math.min(span, 9));
    const b = rand(-Math.min(span, 9), Math.min(span, 9));
    return {
      prompt: `(${a}) × (${b})`,
      answer: a * b,
      choices: choicesFor(a * b),
    };
  }
  return {
    prompt: `${left} + (${right})`,
    answer: left + right,
    choices: choicesFor(left + right),
  };
}
