import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";

export type Skuad = "ombak" | "surya";

export type Biodata = {
  nama: string;
  panggilan: string;
  umur: number;
  kelas: string;
  sekolah: string;
  favorit: number;
  hobi: string;
  cita: string;
  skuad: Skuad;
};

export type Best = { correct: number; stars: number };

export type View = "markas" | "peta" | "bab" | "latihan" | "biodata";

type AcademyState = {
  best: Record<number, Best>;
  biodata: Biodata | null;
  view: View;
  chapterId: number;
  phase: "belajar" | "soal" | "hasil";
  qIndex: number;
  picked: number | null;
  correctCount: number;
  attempt: { correct: number; stars: number } | null;
  openView: (view: View) => void;
  openChapter: (id: number) => void;
  setPhase: (phase: AcademyState["phase"]) => void;
  pick: (index: number, isCorrect: boolean) => void;
  nextQuestion: (total: number) => void;
  restartQuiz: () => void;
  saveBiodata: (biodata: Biodata) => void;
  clearBiodata: () => void;
};

export const useAcademy = create<AcademyState>()(
  persist(
    (set, get) => ({
      best: {},
      biodata: null,
      view: "markas",
      chapterId: 1,
      phase: "belajar",
      qIndex: 0,
      picked: null,
      correctCount: 0,
      attempt: null,
      openView: (view) => set({ view }),
      openChapter: (id) =>
        set({
          view: "bab",
          chapterId: id,
          phase: "belajar",
          qIndex: 0,
          picked: null,
          correctCount: 0,
          attempt: null,
        }),
      setPhase: (phase) =>
        set(
          phase === "hasil"
            ? { phase }
            : { phase, qIndex: 0, picked: null, correctCount: 0 },
        ),
      pick: (index, isCorrect) => {
        if (get().picked !== null) return;
        set((state) => ({
          picked: index,
          correctCount: state.correctCount + (isCorrect ? 1 : 0),
        }));
      },
      nextQuestion: (total) => {
        const { qIndex, correctCount, chapterId, best } = get();
        if (qIndex + 1 >= total) {
          const stars = starsFor(correctCount, total);
          const prev = best[chapterId];
          const nextBest =
            !prev || correctCount > prev.correct ? { correct: correctCount, stars } : prev;
          set({
            phase: "hasil",
            picked: null,
            attempt: { correct: correctCount, stars },
            best: { ...best, [chapterId]: nextBest },
          });
          return;
        }
        set({ qIndex: qIndex + 1, picked: null });
      },
      restartQuiz: () => set({ phase: "soal", qIndex: 0, picked: null, correctCount: 0 }),
      saveBiodata: (biodata) => set({ biodata }),
      clearBiodata: () => set({ biodata: null }),
    }),
    {
      name: "s7-starlink-hunter",
      storage: createJSONStorage(() =>
        typeof window === "undefined"
          ? {
              getItem: () => null,
              setItem: () => {},
              removeItem: () => {},
            }
          : localStorage,
      ),
      partialize: (state) => ({ best: state.best, biodata: state.biodata }),
      skipHydration: true,
    },
  ),
);

export function starsFor(correct: number, total: number) {
  if (total <= 0) return 0;
  const ratio = correct / total;
  if (ratio >= 1) return 3;
  if (ratio >= 0.8) return 2;
  if (ratio >= 0.6) return 1;
  return 0;
}

export function isUnlocked(id: number, best: Record<number, Best>) {
  if (id <= 1) return true;
  return (best[id - 1]?.stars ?? 0) >= 1;
}

export function callsign(nama: string, favorit: number) {
  const words = ["ORBIT", "AURORA", "NOVA", "PULSAR", "COMET", "LYRA"] as const;
  let hash = 0;
  const source = nama.trim().toUpperCase() || "KADET";
  for (const char of source) hash = (hash * 33 + char.charCodeAt(0)) % 997;
  const word = words[Math.abs(hash) % words.length] ?? "ORBIT";
  const number = Math.abs((hash + favorit * 7) % 90) + 10;
  return `${word}-${number}`;
}

export function clearedCount(best: Record<number, Best>) {
  return Object.values(best).filter((item) => item.stars >= 1).length;
}

export function starTotal(best: Record<number, Best>) {
  return Object.values(best).reduce((sum, item) => sum + item.stars, 0);
}
