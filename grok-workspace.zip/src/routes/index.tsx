import { createFileRoute } from "@tanstack/react-router";
import { AcademyApp } from "@/components/academy/academy-app";

export const Route = createFileRoute("/")({ component: AcademyApp });
